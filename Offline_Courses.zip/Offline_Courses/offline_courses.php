<?php
/**
 * Plugin Name: Offline Courses
 * Description: To Add Courses and Book Them; ShortCode [offline_courses_plugin]
 * Version: 1.0
 * Author: IQuinceSoft
 */
 // Set constant
ob_start();
function wpb_adding_css()
{
    wp_enqueue_style('style', plugin_dir_url( __FILE__ ) . '/assets/css/style.css' );
 
	wp_register_style('bootstrap.min', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
	wp_enqueue_style('bootstrap.min');
}
add_action( 'admin_init','wpb_adding_css');

function wpb_adding_scripts() {
     wp_register_script('bootstrap.min.js','https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array( 'jquery' ));
	 wp_enqueue_script('bootstrap.min.js');
   wp_register_script('jquery.min','https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js', array( 'jquery' ));
	 wp_enqueue_script('jquery.min');
    
	 wp_register_script('validate', plugins_url( '/assets/js/validate.js', __FILE__ ), array( 'jquery' ));
	wp_enqueue_script('validate');
    
}
add_action( 'admin_footer', 'wpb_adding_scripts' );

define('PLUGIN_DIR', plugin_dir_path( __FILE__ ));

/** include functions defination*/
include_once PLUGIN_DIR.'functions.php';

/** include pages*/
include "pages/admin/add_new_courses.php"; 
include "pages/admin/view_all_courses.php";
include "pages/user/find_a_course.php";
  
function theme_options_panel(){
add_menu_page('menu-title', 'Offline Courses', 'manage_options', 'courses-slug', 'view_all_courses',plugin_dir_url( __FILE__ ) . '/assets/icon.png',2);

add_submenu_page( 'courses-slug', 'add-courses', 'Add Courses',
    'manage_options', 'add-courses-slug', 'add_new_courses'); 
}
add_action('admin_menu', 'theme_options_panel'); 

/* Database Table Migration Section */
global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
	global $wpdb;
	global $jal_db_version;

	$table_name = $wpdb->prefix . 'offline_courses';
	$charset_collate = $wpdb->get_charset_collate();
    
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
         $sql = "CREATE TABLE `$table_name` ( `id` INT NOT NULL AUTO_INCREMENT , `course_name` VARCHAR(255) NOT NULL , `discipline` VARCHAR(255) NOT NULL , `level` VARCHAR(191) NOT NULL , `location` VARCHAR(191) NOT NULL , `duration` TINYINT NOT NULL , PRIMARY KEY (`id`)) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
    }
	add_option( 'jal_db_version', $jal_db_version );
}

function jal_install_data() {
	global $wpdb;
	global $jal_db_version;

	$table_name = $wpdb->prefix . 'offline_courses_status';
	$charset_collate = $wpdb->get_charset_collate();
    
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) 
    {
	$sql = "CREATE TABLE `$table_name` ( `id` INT NOT NULL AUTO_INCREMENT , `course_id` INT NOT NULL , `start_date` DATE NOT NULL , `end_date` DATE NOT NULL , `status` INT NOT NULL , PRIMARY KEY (`id`)) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
    }
	add_option( 'jal_db_version', $jal_db_version );
}
register_activation_hook( __FILE__, 'jal_install' );
register_activation_hook( __FILE__, 'jal_install_data' );
/* Database Table Migration Section End */

/* Sortcode Offline course frontend */

add_shortcode('offline_courses_plugin', 'front_end');
?>

