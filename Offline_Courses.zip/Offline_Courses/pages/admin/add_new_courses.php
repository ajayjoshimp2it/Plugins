<?php
function add_new_courses(){ ?>
<div class="container">
    <div class="row">
        <?php                        
            if(isset($_GET['new_course']) && ($_GET['new_course']=== 'true'))
            {
                ?>
                <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Congratulation!</strong> Data inserted successfully.
                </div>
        <?php 
            }else if(isset($_GET['new_course']) && ($_GET['new_course']=== 'false'))
            { ?>
            <div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Sorry!</strong> Data not inserted.
            </div>
        <?php } ?>
    <fieldset>
        <legend><h2>Add New Course</h2></legend>
        <form class="form-horizontal" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <div class="form-group">
                <label class="col-sm-2 control-label" for="card-holder-name">Course Name</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="course_name" name="course_name" placeholder="Course Name" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label" for="card-holder-name">Discipline</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="discipline" name="discipline" placeholder="Discipline" required>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label" for="card-holder-name">Level</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="level" name="level" placeholder="Level" required>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label" for="card-holder-name">Location</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" id="location" name="location" placeholder="Location" required>
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label" for="card-holder-name">Duration</label>
                <div class="col-sm-8">
                    <input type="number" min="0" class="form-control" name="duration" placeholder="Days" required>
                </div>
            </div>


            <div class="form-group">
                <label class="col-sm-2 control-label" for="cvv">Date</label>
                <div class="col-sm-3">
                    <p><input type="date" class="form-control" name="date[]" required></p>
                    <div id="date"></div>
                </div>
                <div class="col-sm-1">
                <a onclick="add_date()" class="btn btn-info pull-right">Add Date</a>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-12">
                    <input type="hidden" name="action" value="course_form">
                    <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                </div>
            </div>
        </form>
    </fieldset>        
    </div>
</div>
<script>
    var i = 1;
    function add_date()
    {
        var d1 = document.getElementById('date');
        d1.insertAdjacentHTML('beforeend', '<p id="'+i+'"><input type="date" class="form-control" name="date[]" ><a onclick="remove_date('+i+')"><span class="glyphicon glyphicon-remove"></span></a></p>');
        i++;
    }
    function remove_date(date_id)
    {
        jQuery("#"+date_id).remove();
    }   
</script>
<?php } ?>

