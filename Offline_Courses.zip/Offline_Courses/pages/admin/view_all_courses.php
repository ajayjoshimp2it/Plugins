<?php function view_all_courses() { ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12 col-sm-12">
            
            <center><h2>View All Courses</h2></center>
            
            <?php                        
            if(isset($_GET['edit_course']) && ($_GET['edit_course']=== 'true'))
            {
                ?>
                <div class="alert alert-info alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong>Congratulation!</strong> Data Updated successfully.
                </div>
            <?php 
                }else if(isset($_GET['edit_course']) && ($_GET['edit_course']=== 'false'))
                { ?>
                <div class="alert alert-danger alert-dismissible">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <strong>Sorry!</strong> Data not Updated.
                </div>
            <?php } ?>
            
            <div id="status"></div>
            <!-- Courses Displaying here Start -->
            <div id="course_data">
                
            </div>
            <!-- Courses Displaying Section Ends -->
            
<!-- Trigger the modal with a button -->
<input type="hidden" id="trigger" data-toggle="modal" data-target="#myModal">

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit Course</h4>
      </div>
      <div class="modal-body">
          <!-- Content Goes Here -->
      </div>
      <div class="modal-footer">
        <button type="button" id="trigger_close" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- Model Ends Here -->
        </div>
    </div>
</div>
<script>
jQuery(document).ready(function(){
    jQuery.ajax({
        type: 'POST',
        url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
        data: { page: 1 },
        error: function() {
            alert("Sorry! Something went wrong.")
        },
        beforeSend: function() {
            jQuery(".modal-title").html("<center>Data Loading...</center>");
            jQuery("#trigger").trigger("click");
        },
        success: function(e) {
            jQuery("#course_data").html(e);
            jQuery("#trigger_close").trigger("click");
        }
    }); 
});
</script>
<?php } ?>