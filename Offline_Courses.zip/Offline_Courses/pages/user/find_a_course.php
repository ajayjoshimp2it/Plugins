<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

<link rel="stylesheet" type="text/css" href="<?php echo get_site_url();?>/wp-content/plugins/Offline_Courses/assets/css/style.css">
 
<!-- jQuery -->
<script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-1.12.4.js"></script>
 
<!-- DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<style>
.dataTables_filter label,#find_course_length label, .crs-nm-hide {
    display: none;
}
</style>

<?php function front_end(){ ?>
<div class="container-fluid">
    <div class="row">
                
        <table id="find_course" class="display" style="width:100%">

        <thead>
            <tr>
                <th>Course Name</th>
                <th>Discipline</th>
                <th>Level</th>
                <th>Loction</th>
                <th>Duration</th>
                <th>Date</th>
                <th>Book Course</th>
            </tr>
        </thead>
            
        <tbody>
<?php
/*fetch db*/
global $wpdb;
$table_name1 = $wpdb->prefix . 'offline_courses';
$table_name2 = $wpdb->prefix . 'offline_courses_status';
$result = $wpdb->get_results( "SELECT oc.*,GROUP_CONCAT(' ',ocs.start_date) as start_date FROM `$table_name1` as oc join `$table_name2` as ocs on oc.id=ocs.course_id group by oc.id");

foreach($result as $data) 
{   ?>
    <tr>
        <td><?= $data->course_name; ?></td>
        <td><?= $data->discipline; ?></td>
        <td><?= $data->level; ?></td>
        <td><?= $data->location; ?></td>
        <td><?= $data->duration; ?></td>
        <td><?= $data->start_date; ?></td>
        <td><a class="btn btn-default" onclick="select_course_ajax(<?= $data->id; ?>)">Book Now</a></td>
    </tr>
    <?php 
} 
?>
        </tbody>
        <tfoot>
            <tr>
                <th>Discipline:</th>
                <th>Discipline</th>
                <th>Loction:</th>
                <th>Loction</th>
                <th class="crs-nm-hide">Duration</th>
                <th class="crs-nm-hide">Date</th>
            </tr>
        </tfoot>
    </table>
        
    </div>
</div> 
<div id="src-filter">
<div class="row"></div>
</div>   

<!-- Trigger the modal with a button -->
<input type="hidden" id="trigger" data-toggle="modal" data-target="#myModal">

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Book Course</h4>
      </div>
      <div class="modal-body">
          <!-- Content Goes Here -->
    </div>
  </div>
</div>
<!-- Model Ends Here -->
<script>

$(document).ready(function() {
    $('#find_course').DataTable( {
        initComplete: function () {
            this.api().columns([1,3]).every( function () {
                var column = this;
                var select = $('<select><option value="">Show all</option></select>')
                    .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        }
    } );
    jQuery( "#src-filter" ).prependTo( ".dataTables_wrapper" );
    jQuery('#find_course tfoot tr').appendTo('#src-filter .row');
    jQuery('#find_course_length').appendTo('#src-filter .row');
} );

function select_course_ajax(course_id)
{
    jQuery.ajax({
            type: 'POST',
            url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
            data: { select_course: 'true', course_id: course_id },
            error: function() {
                alert("Sorry! Something went wrong.")
            },
            beforeSend: function() {
            },
            success: function(data) {
                jQuery(".modal-body").html(data);
                jQuery( "#trigger" ).trigger( "click" );
            }
        });
}
   
</script>    
<?php } ?>  


        