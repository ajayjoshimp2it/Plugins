<?php
if ( !class_exists('Puc_v4_Factory', false) ):

	class Puc_v4_Factory extends Puc_v4p9_Factory { }

endif;
