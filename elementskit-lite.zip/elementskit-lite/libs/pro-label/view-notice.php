<div class="ekit-go-pro-notice">
    <h2>Thank you for using ElementsKit</h2>
    <p>To take full advantages of Elementskit and get the outstanding readymade layouts, please buy <strong>pro version</strong>.</p>
</div>