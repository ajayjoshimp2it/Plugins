=== Elements kit Elementor addons (Header & Footer Builder, Mega Menu Builder, Layout Library) ===
Contributors: Ataurr, wpmet, emrnco, golaphazi, pobonpaul1994, easin55474, khalidjubair
Tags: elementor addons, mega menu, header footer builder, elements, elementor extensions, elementor modules, page builder addons, elementor addon, elementor widget, addons
Requires at least: 4.6
Tested up to: 5.3
Stable tag: 1.3.7
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Elementskit All in one addon for Elementor page builder. It includes most comprehensive modules, such as header footer builder, mega menu Builder Layout kit etc under the hood. It has 40+ custom widgets to create any sites with ease.

== Description ==

<iframe width="560" height="315" src="https://www.youtube.com/embed/ECFC0QregXg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

Elementskit is an ultimate All in one addon for Elementor page builder. It includes most comprehensive modules, such as header footer builder, mega menu Builder Layout kit etc under the one hood. It has 40+ custom widgets to create any sites with ease. It has some most unique and powerful custom controls for elementor, such as image picker, ajax select2, Advanced widget etc. Why you need multiple plugins? Where everything under the one hood?


Elements kit Elementor addons have Exclusive features that blow your mind. Like mega menu builder, Header and footer builder layout library so on. 



== <a href="http://go.wpmet.com/ekitpro"> Check our Live Demos</a> ==


###SUPPORT###

Found issue or new features? [Contact our team from here](https://help.wpmet.com/). 

==== KEY FEATURES ====
- 40+ Fully Customizable Elementor widgets addons.
- Header and Footer builder module.
- Elementor menu Megamenu builder.
- Layout Pack Library.
- Elementor gallery pack. Filterable, masonry, grid
- Fully Responsive and Cross Browser Compatible
- No Coding knowledge required



== Layoutkit library ==

With Elementskit we have Layout library features where over 7+ ready-made home available and 300+ ready-made section available. Just click the layout icon and insert it into your site, it's so easy to use without any hassle like import JSON.  You will get a complete native feel when you use this.

== 250+ Ready blocks ==
Elements Kit All in one elementor addon comes with 250+ readymade blocks.  Make any website on the fly with readymade blocks from the Exclusive layout kit library. You don't need to create from scratch just input the design from layout kit library and modify according to your need that’s it. Your site now ready to launch.

== Modular based and Lightweight  ==
Elements Kit build optimization in mind. We develop our plugin Modular based so if you don't need any addons or shortcode. You can enable/disable specific elements from  Elements Kit option panel to prevent overloading your website with Extra  CSS or JS code you will not use which helps your website have a blazing fast performance. 

== Completely Customizable  ==
Every elementor widgets have Huge customizable options to control any widgets modify according to your needs.  You can build any style you want with our plugin.

== 35+ FREE WIDGETS AND COUNTING ==

We have over 35+ elementor widgets with our free plugin. And Every elementor widget Build with care. We can say that this elementor widget pack in best in town with design as well controls and features.

- <a href="https://products.wpmet.com/elementskit/heading/">Heading Title</a>
- <a href="https://products.wpmet.com/elementskit/button/">Button</a>
- <a href="https://products.wpmet.com/elementskit/team/">Team</a>
- <a href="https://products.wpmet.com/elementskit/accordion/">Accordion</a>
- <a href="https://products.wpmet.com/elementskit/tab/">Tab</a>
- <a href="https://products.wpmet.com/elementskit/social-media/">Social Media</a>
- <a href="https://products.wpmet.com/elementskit/blog/">Recent Blog</a>
- <a href="https://products.wpmet.com/elementskit/client-logo/">Client and sponsor logo</a>
- <a href="https://products.wpmet.com/elementskit/countdown-timer/">Countdown Timer, Clock timer</a>
- <a href="https://products.wpmet.com/elementskit/faq/">FAQ</a>
- <a href="https://products.wpmet.com/elementskit/funfact/">FunFact</a>
- <a href="https://products.wpmet.com/elementskit/heading/">Heading</a>
- <a href="https://products.wpmet.com/elementskit/icon-box/">Icon box</a>
- <a href="https://products.wpmet.com/elementskit/image-accordion/">Image Accordions</a>
- <a href="https://products.wpmet.com/elementskit/image-box/">Image Box</a>
- <a href="https://products.wpmet.com/elementskit/pie-chart/">Piechart</a>
- <a href="https://products.wpmet.com/elementskit/pricing-new/">Pricing</a>
- <a href="https://products.wpmet.com/elementskit/progress-bar/">Progress bar</a>
- <a href="https://products.wpmet.com/elementskit/testimonial/">Testimonial</a>
- <a href="https://products.wpmet.com/elementskit/mail-chimp/">MailChimp</a>
- <a href="https://products.wpmet.com/elementskit/gallery/">Gallery</a>
- <a href="https://products.wpmet.com/elementskit/image-comparision">Image Comparison</a>
- <a href="https://products.wpmet.com/elementskit/call-to-action/">Call to action</a>
- <a href="https://products.wpmet.com/elementskit/video/">Video</a>
- <a href="https://products.wpmet.com/elementskit/contact/">Contact form 7 Contact form</a>
- <a href="https://products.wpmet.com/elementskit/post-tab/">Post Tab</a>
- <a href="https://products.wpmet.com/elementskit/hotspot/"></a>
- <a href="https://products.wpmet.com/elementskit/post-list/">Post list</a>
- <a href="https://products.wpmet.com/elementskit/page-list/">Page list</a>
- <a href="https://products.wpmet.com/elementskit/offcanvas/"> Offcanvas Menu</a>
- <a href="https://products.wpmet.com/elementskit/drop-caps/">Drop Caps</a>
- <a href="https://products.wpmet.com/elementskit/social-media/">Social Media</a>
- <a href="https://products.wpmet.com/elementskit/call-to-action/">Call To Action</a>
- <a href="https://products.wpmet.com/elementskit/dual-button-2/">Dual Button</a>
- <a href="https://products.wpmet.com/elementskit/business-hours/">Business Hours</a>
- <a href="https://products.wpmet.com/elementskit/social-share/">Social share</a>
- <a href="https://products.wpmet.com/elementskit/caldera-form/">Caldera Form</a>
- <a href="https://products.wpmet.com/elementskit/category-list/">Category List</a>
- <a href="https://products.wpmet.com/elementskit/header-search/">Search</a>


== Exclusive modules ==
We have developed Awesome exclusive modules which saved tons of time when you are developing your site. As well it will saved your time to develop your site within shortime.

- Header and footer builder
-<a href="https://products.wpmet.com/megamenu/">Megamenu builder (PRO Layout)</a> 


== Exclusive PRO Addons widgets ==

- <a href="https://products.wpmet.com/elementskit/advaced-accordion/">Advanced Accordion (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/advance-tab/">Advanced Tab(PRO)</a>
- <a href="https://products.wpmet.com/elementskit/time-line/">Timeline (Pro)</a>
- <a href="https://products.wpmet.com/elementskit/instagram/">Instagram feed (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/facebook-feed/">Facebook feed (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/twitter/">Twitter feed (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/chart/">Advanced Chart (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/table/">Data Table (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/hotspot/">Hotspot (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/creative-buttons/">Creative button (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/motion-text/">Motion text (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/woo-product-list/">Woocommerce Product List (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/woo-product-carousel/"> Woocommerce Product Carousel (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/woo-category-list/"> Woocommerce Category List (PRO)</a>
- <a href="https://products.wpmet.com/elementskit/woo-mini-cart/"> Woocommerce Mini Cart (PRO)</a>





== PRO Modules Features in premium version ==

- Parallax options with SVG library and animations (HOT)
- Sticky content in any place.
- Header footer in specific page or post.
- Add Icon and label in the mega menu.
-  Widgets area

== COMMON ISSUES AND FIX ==
=== Elementor editor fails to load or not working? ===
It's due to your server PHP settings. Increase your server PHP memory limit from the wp-config.php file or php.ini file.  If you don't have an idea about it. Please contact your hosting provider and ask to increase 
* PHP memory_limit = 512M
* max_execution_time = 300

== Changelog ==

V1.3.4
Bug Fixed
WordPress 5.3 compatibility 

V1.3.3
Bug Fixed
Menu parent liable in mobile

V 1.3.2
Bug Fixed
Update Social API 


V 1.3.0
Fontawesome 5 supported.
Widget area bug fix for off-canvas widget
added new controls to tab, accordion
Minor css fix

V 1.2.7
Polylang Support for Search widget - Thanks to Alain Melsens
CSS Bug Fixed 
Fixed Elementor pro popup issue
Header footer support for twenty nineteen and My listing theme.



V1.2.6
Missing ajax-loader.gif
Accordion active tab issue
New controls to the page list, post-list widgets
Controls aren’t working on icon box, image box
Off-canvas hide issue in the nav-menu widget (mobile view)
CSS improvement
Admin icon missing


v1.2.5
Fixed 3rd party plugin compatible issue.


v1.2.4
Burger menu issue fixed
Post tab bug fixed

v1.2.3
Huge Performance improvement


v1.1.3
Performance improvement
CSS Bugfix

* Initial release

== Upgrade Notice ==
Wordpress 4.9+

== Screenshots ==



== Installation ==



1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. All Settings will be found in Admin sidebar -> elementskit menu
4. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)



== Frequently Asked Questions ==

= How to use elementskit? =

Login your WordPress dashboard,  From the left menu click elementskit icon. 

= Any video documentation? =
We have video screencasts. Please check here https://www.youtube.com/watch?v=wdRHvH6znIw&list=PL3t2OjZ6gY8MVnyA4OLB6qXb77-roJOuY




