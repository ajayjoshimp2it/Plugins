<?php
/**
 * Template Library Header Template
 */
?>
<label>
	<input type="radio" value="{{ slug }}" name="elementskit-library-tab">
	<span>{{ title }}</span>
</label>