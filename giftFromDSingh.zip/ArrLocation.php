<?php
date_default_timezone_set("UTC"); 
echo "UTC:".time("h:m:s"); 
echo "<br>"; 

date_default_timezone_set("asia/kolkata"); 
echo "Europe/Helsinki:".date ('H:m:s'); 
echo "<br>"; 

$arr = array('a','b','c','d','e','f','g','h','i');
echo $arr[3]."<br>";
echo array_search('d', array_values($arr)).$arr[array_search('d', array_values($arr))];
?>