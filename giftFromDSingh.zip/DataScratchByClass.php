<?php
$url = 'https://www.zillow.com/lender-profile/CarlosFigueira/';

$context = stream_context_create(array(
'https' => array(
'method' => 'GET',
'header' => 'Content-Type: text/html; charset=utf-8',
'content' => 'text'
)
));
$result = file_get_contents($url, false, $context);
    $classname = 'zsg-content-component dont-break-out';
    $dom = new DOMDocument;
    libxml_use_internal_errors(true);
    $dom->loadHTML($result);
    libxml_use_internal_errors(false);
    $xpath     = new DOMXPath($dom);
    $results = $xpath->query("//*[@class and contains(concat(' ', normalize-space(@class), ' '), ' $classname ')]");

print_r($result);
/*echo "<pre>";
for($i = 0; $i< $results->length; $i++)
{
    echo $results->item($i)->nodeValue."<br>";
}*/


    /*@$classnames = 'ax_h4';
    @$doms = new DOMDocument;
    @$doms->loadHTML($result);
    @$xpaths     = new DOMXPath($doms);
    @$resultss = $xpaths->query("//*[@class and contains(concat(' ', normalize-space(@class), ' '), ' $classnames ')]");

    if ($resultss->length > 0) {
        echo $review = $resultss->item(8)->nodeValue;
        echo $review = $resultss->item(10)->nodeValue;
    }*/
?>