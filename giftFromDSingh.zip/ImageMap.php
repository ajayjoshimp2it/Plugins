<ul style="list-style: none;">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "images";

global $conn; 
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
$sql = "select code from codes";
$result = $conn->query($sql);    
while($row = $result->fetch_assoc()) {
    if($row['code']){
        get_image_name($row['code']);
    }else{
        break;
    }
}
    function get_image_name($code){
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "images";
        $conns = new mysqli($servername, $username, $password, $dbname);
        $subsql = "select image from images where image LIKE '%$code%'";
        $subresult = $conns->query($subsql);
        echo "<li>";
        $count = $subresult->num_rows;
        if($count){
        $countA = 1;
        while($subrow = $subresult->fetch_assoc()) {
            if($countA < $count){
                $val = ",";
            }else{
                $val="";
            }$countA++;
            echo "https://www.rugsmadeinusa.com/images/".$subrow['image'].$val;
        }
        }else{
            echo "null";
            /*echo "http://tapetesorientales.com/dakota_images/".$code.".jpg";*/
        }
        
        echo "</li>";
    }
?>
</ul>    

