<?php
$filename="myimage.jpg";
$img = imagecreatefromjpeg($filename);
header("Content-Type: image/jpeg");
imagejpeg($img, $filename, 100);
?>
<?php
scandir();
imagecopyresampled();
imagecopyresized();
?>