<?php
$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "Mickey Mouse\n";
fwrite($myfile, $txt);
echo file_put_contents("newfile.txt","Hello World. Testing!",FILE_APPEND);
fclose($myfile);
?>