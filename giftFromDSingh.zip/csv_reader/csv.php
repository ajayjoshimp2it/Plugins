<?php
/*global $wpdb;

if(current_user_can('administrator')):*/
/*$csvFile = file(get_theme_root().'/dumpster/kentucky1.csv');

foreach ($csvFile as $line) {

  $post_id = wp_insert_post( array(
  'post_author' => 1,
  'post_title'  => str_getcsv($line)[1],
  'post_status' => 'publish',
  'post_type'   => 'dumpster',
  'post_category' => array(46),
  'meta_input'  => array(
    '_zip_code_custom_meta' => str_getcsv($line)[0],
    '_city_custom_meta'     => str_getcsv($line)[1]
  )
));

$wpdb->insert( ‘wp_term_relationships’, array( ‘object_id’ => $post_id, ‘term_taxonomy_id’ => 44, 'term_order' => 0 ) );
}*/
/*$post_id = wp_insert_post( array(
  'post_author' => 1,
  'post_title'  => 'DSingh',
  'post_status' => 'publish',
  'post_type'   => 'dumpster',
  'post_category' => array(46),
  'meta_input'  => array(
    '_zip_code_custom_meta' => '1001',
    '_city_custom_meta'     => 'Dushyant'
  )
));

 echo "post ID".$post_id."<br>";

echo $wpdb->insert( 'wp_term_relationships', array( 'object_id' => $post_id, 'term_taxonomy_id' => 46, 'term_order' => 0 ) );

echo "<br>Ho gaya Paji <br>";
die;
endif;*/