
<?php 
$csvFile = file('kentucky1.csv');
print_r(get_theme_root());
/*foreach ($csvFile as $line) {
print_r(array(
	'post_author' => 1,
	'post_title'  => str_getcsv($line)[1],
	'post_status' => 'publish',
	'post_type'   => 'dumpster',
	'meta_input'  => array(
		'_zip_code_custom_meta' => str_getcsv($line)[0],
		'_city_custom_meta'     => str_getcsv($line)[1]
	)
));*/

	/*wp_insert_post( array(
	'post_author' => 1,
	'post_title'  => str_getcsv($line)[1],
	'post_status' => 'publish',
	'post_type'   => 'dumpster',
	'meta_input'  => array(
		'_zip_code_custom_meta' => str_getcsv($line)[0],
		'_city_custom_meta'     => str_getcsv($line)[1]
	)
));*/
/*}*/
