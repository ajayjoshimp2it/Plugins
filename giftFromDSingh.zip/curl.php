<?php
$curl = curl_init();
$url = "https://www.amazon.in/";//Put URL
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($curl);
ob_start(); 
print_r($result);																									 
$cont = ob_get_contents();
preg_match_all('/src="([^"]*)"/',$cont, $contArray); 
ob_end_clean();
echo '<pre>';
foreach ($contArray[1] as $url){
$imgURL = $url;
$explodedImageUrl = explode('/',$imgURL); 
$length = count($explodedImageUrl);   
$imgName = $explodedImageUrl[$length-1];
echo $imgName."<br>";    
/*$file_parts = pathinfo($imgName);
  
if( isset($file_parts['extension']) ){
    switch($file_parts['extension']){
        case 'jpg':
        saveImage( $url , $imgName );
        break;
        
        case 'png':
        saveImage( $url , $imgName );
        break; 
        
        case 'jpeg':
        saveImage( $url , $imgName );
        break;
            
        case 'gif':
        saveImage( $url , $imgName );
        break; 
        case 'svg':
        saveImage( $url , $imgName );
        break;
            
        case 'js':
        break; 
            
        default:
        saveImage( $url , rand(100,10000).'.png' );    
        break;       
    }       
} */   
}
function saveImage( $url , $imgName ){
    if(preg_match('/http/i',$url)){
    $file   = file($url);
    $result = file_put_contents("img/".$imgName, $file);
    }else{
        echo 'Image '.$url.' Not Found!<br>'; 
    }    
}  
echo "Udi Baba Mamuni, apni images download ho gayi hain :)";
?>