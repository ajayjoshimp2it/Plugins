<?php
if(isset($_GET['submit']) and !empty($_GET['url'])):
function file_get_contents_curl($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       

    $data = curl_exec($ch);
    curl_close($ch);

    return strip_tags($data);
}
preg_match_all('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}/i',file_get_contents_curl($_GET['url']), $contArray);
echo '<ul style="list-style-type: none;">';
foreach($contArray[0] as $id){
	echo "<li>".$id."</li>";
}
else:
?>
<form method="get">
<input type="text" name="url" placeholder="Enter URL" />
<input type="submit" name="submit" />
</form>
<?php endif; ?>