<?php 
/*
 * Add new record to the databse
 * @param data 
 */
ob_start();
include_once('../../../wp-load.php');
/* Add New Course Section Start */
if ( isset( $_POST['submit'] ) && $_POST['action'] == 'course_form' )
{
    if(insert_new_courses($_POST)){
        $url= get_site_url()."/wp-admin/admin.php?page=add-courses-slug&new_course=true";
        header('location: '.$url.'');  
    }
    else{
        $url= get_site_url()."/wp-admin/admin.php?page=add-courses-slug&new_course=false";
        header('location: '.$url.'');
    }
}

function insert_new_courses()
{ 
    global $wpdb;
    $tablename=$wpdb->prefix.'offline_courses';
    $data=array(
    'course_name' => $_POST['course_name'],
     'discipline' => $_POST[ 'discipline'],
     'level' => $_POST[ 'level'],
     'location' => $_POST[ 'location'],
     'duration' => $_POST['duration']
    );
    $result_offline_courses = $wpdb->insert( $tablename, $data);
    $last_id = $wpdb->insert_id;
    
    foreach($_POST['date'] as $date)
    {
        $start_date = strtotime($date);
        $end_date = strtotime('+'.$_POST['duration'].' day',$start_date);
        $end_date = date('y-m-d',$end_date);
        
        $tablename = $wpdb->prefix.'offline_courses_status';
        $data=array(
        'course_id' => $last_id,
         'start_date' => $date,
         'end_date' => $end_date,
         'status' => 1
        );
       $result_offline_courses_status = $wpdb->insert( $tablename, $data);
        
    }
    
    if($result_offline_courses && $result_offline_courses_status)
    {
        return true;
    }else{
        return false;
    }
}
/* Add New Course Section End */

/* Courses pagination Start Here */
if ( isset( $_POST['page'] ))
{
    ob_get_clean();
    viwe_all_courses($_POST['page']);
}
/* Courses pagination Start End */

/* View Courses Section Start */
function viwe_all_courses()
{
global $wpdb;
$table_name1 = $wpdb->prefix . 'offline_courses';
$table_name2 = $wpdb->prefix . 'offline_courses_status';
$wpdb->get_results("SELECT id FROM $table_name1");
$total_pages = ceil($wpdb->num_rows / 10);  
    if($_POST['page'] > 1)
    {
        $offset = ($_POST['page']-1)*10;
    }else{
        $offset = 0;
    }

    $result = $wpdb->get_results( "SELECT oc.*,GROUP_CONCAT(' ',ocs.start_date) as start_date,GROUP_CONCAT(ocs.status) as status  FROM `$table_name1` as oc join `$table_name2` as ocs on oc.id=ocs.course_id group by oc.id order by oc.id desc limit 10 offset $offset" );
    if(!$result)
    { ?>
        <div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Sorry!</strong> No Data Available.
            </div>
    <?php 
    }
    else
    { ?>
            <table class="table table-striped table-hover" id="#">
            <thead>
              <tr>
                <th>Course Name</th> 
                <th>Discipline</th>
                <th>Level</th>
                <th>Location</th>
                <th>Duration</th>
                <th>Date</th> 
                <th>Action</th>  
              </tr>
            </thead>
            <tbody>

            <?php foreach($result as $data) { ?>

              <tr id="<?= $data->id; ?>">
                <td><?= $data->course_name; ?></td>
                <td><?= $data->discipline; ?></td>
                <td><?= $data->level; ?></td>
                <td><?= $data->location; ?></td>
                <td><?= $data->duration; ?></td>
                <td><?= $data->start_date; ?></td>
                  <td><a onclick="edit_course_ajax(<?= $data->id; ?>)"><span class="glyphicon glyphicon-pencil"></span></a>&emsp;<a onclick="delete_course_ajax(<?= $data->id; ?>)"><span class="glyphicon glyphicon-trash"></span></a></td>
              </tr>

            <?php } ?>
            </tbody>
            </table>

<div class="col-md-4 col-sm-4 pull-right">
    <div class="pagination"><?php 
        if($_POST['page']>3)
        { ?>
            <a onclick="pagination(1)" class="btn btn-default">First</a><?php 
        }
        for( $i= max($_POST['page']-2,1); $i<=min($_POST['page']+2,$total_pages); $i++){ 
             
            if($_POST['page']==$i)
            { ?>
                <a onclick="pagination(<?= $i ?>)" class="active"><?= $i ?></a><?php 
            }else
            { ?>
                <a onclick="pagination(<?= $i ?>)"><?= $i ?></a><?php 
            }
        } 
        if($_POST['page']<$total_pages-2)
        { ?>
            <a onclick="pagination(<?= $total_pages ?>)" class="btn btn-default">Last</a><?php
        } ?>  
    </div>
</div>
<script>
        function pagination(page)
    {
        jQuery.ajax({
            type: 'POST',
            url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
            data: { page: page },
            error: function() {
                alert("Sorry! Something went wrong.")
            },
            beforeSend: function() {
            },
            success: function(e) {
                jQuery("#course_data").html(e);
            }
        });  
    }
    
    function edit_course_ajax(id){
        jQuery.ajax({
            type: 'POST',
            url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
            data: { edit_course: 'true', course_id: id },
            error: function() {
                alert("Sorry! Something went wrong.")
            },
            beforeSend: function() {
            },
            success: function(data) {
                jQuery(".modal-body").html(data);
                jQuery( "#trigger" ).trigger( "click" );
            }
        });
    }
    
    function delete_course_ajax(id){
        if (confirm("Are you sure to delete it."))
            {
                jQuery.ajax({
            type: 'POST',
            url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
            data: { delete_course: 'true', course_id: id },
            error: function() {
                alert("Sorry! Something went wrong.")
            },
            beforeSend: function() {
            },
            success: function(data) {
                jQuery("#status").html('<div class="alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Deleted!</strong> Data Deleted Successfully.</div>');
                jQuery("#"+id).hide();
            }
        });   
            }
        
    }
</script>    
<?php 
    }        
}
/* View Courses Section End */

/* Edit Courses Section Start */

if($_POST['edit_course']== 'true'){
    ob_get_clean();
    edit_course($_POST['course_id']);    
}    
function edit_course($id) 
{   
    global $wpdb;
    $table_name1 = 'wp_offline_courses';
    $table_name2 = 'wp_offline_courses_status';
    $result_oc = $wpdb->get_results("select * from `$table_name1` where id = $id");
    $result_ocs = $wpdb->get_results("select id,start_date from `$table_name2` where course_id = $id");
    ?>
<form class="form-horizontal" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <div class="form-group">
        <label class="col-sm-2 control-label" for="card-holder-name">Course Name</label>
        <div class="col-sm-8">
            <input type="hidden" name="oc_id" value="<?= $result_oc[0]->id; ?>" />
            <input type="text" class="form-control" id="course_name" name="course_name" placeholder="Course Name" value="<?= $result_oc[0]->course_name; ?>" />
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label" for="card-holder-name">Discipline</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="discipline" name="discipline" placeholder="Discipline" value="<?= $result_oc[0]->discipline; ?>" />
        </div>
    </div>


    <div class="form-group">
        <label class="col-sm-2 control-label" for="card-holder-name">Level</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="level" name="level" placeholder="Level" value="<?= $result_oc[0]->level; ?>" />
        </div>
    </div>


    <div class="form-group">
        <label class="col-sm-2 control-label" for="card-holder-name">Location</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="location" name="location" placeholder="Location" value="<?= $result_oc[0]->location; ?>" />
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label" for="card-holder-name">Duration</label>
        <div class="col-sm-8">
            <input type="number" min="0" class="form-control" name="duration" placeholder="Days" value="<?= $result_oc[0]->duration; ?>" />
        </div>
    </div>


    <div class="form-group">
        <label class="col-sm-2 control-label" for="date">Date</label>
        <div class="col-sm-4">
            <?php foreach($result_ocs as $ocs) { ?>
            <p id="ocs_date">
                <input type="hidden" name="date_id[]" value="<?= $ocs->id; ?>">
                <input type="date" class="form-control" name="date[]" value="<?= $ocs->start_date; ?>">
<!--
                <a onclick="var elem = document.getElementById('ocs_date');elem.parentNode.removeChild(elem);">     <span class="glyphicon glyphicon-remove"></span>
                </a>
-->
            </p>
            <?php } ?>
            <div id="date"></div>   
        </div>
        <div class="col-sm-2">
        <a onclick="add_date()" class="btn btn-info pull-right">Add Date</a>
        </div>
    </div>


    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-12">
            <input type="hidden" name="action" value="course_form_edit">
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </div>
    </div>
</form>
<script>
    var i = 0;
    function add_date()
    {
        var d1 = document.getElementById('date');
        d1.insertAdjacentHTML('beforeend', '<p id="'+i+'"><input type="hidden" name="date_id[]" value"0"><input type="date" class="form-control" name="date[]" ><a onclick="remove_date('+i+')"><span class="glyphicon glyphicon-remove"></span></a></p>');
        i--;
    }
    function remove_date(date_id)
    {
        jQuery("#"+date_id).remove();
    }   
</script>
        <?php
        
}
/* Edit Courses Section End */

/* Delete Courses Section Start */

if($_POST['delete_course']=== 'true'){
    ob_get_clean();
    delete_course($_POST['course_id']);    
}    
function delete_course($id)
{   
    global $wpdb;
    $table_name1 = 'wp_offline_courses';
    $table_name2 = 'wp_offline_courses_status';
    $result_oc = $wpdb->get_results("delete from `$table_name1` where id = $id");
    $result_ocs = $wpdb->get_results("delete from `$table_name2` where course_id = $id");
}
/* Delete Courses Section End */

/* Edit Course Section Start */
if ( isset( $_POST['submit'] ) && $_POST['action'] == 'course_form_edit' )
{
    ob_get_clean();
    if(edit_course_data($_POST))
    {
        $url= get_site_url()."/wp-admin/admin.php?page=courses-slug&edit_course=true";
        header('location: '.$url.'');  
    }
    else{
        $url= get_site_url()."/wp-admin/admin.php?page=courses-slug&edit_course=false";
        header('location: '.$url.'');
    }
}

function edit_course_data()
{ 
    global $wpdb;
    $table1 = $wpdb->prefix.'offline_courses';
    $table2 = $wpdb->prefix.'offline_courses_status';
    $where_oc = array('id' => $_POST['oc_id']);
    $where_ocs = array('course_id' => $_POST['oc_id']);
    
    $data_oc=array(
    'course_name' => $_POST[ 'course_name'],
     'discipline' => $_POST[ 'discipline'],
     'level' => $_POST[ 'level'],
     'location' => $_POST[ 'location'],
     'duration' => $_POST['duration']
    );  
    
    $updated_table1 = $wpdb->update( $table1, $data_oc, $where_oc, $format = null, $where_format = null );

    $wpdb->delete( $table2, $where_ocs, $where_format = null );
    
    foreach($_POST['date'] as $date)
    {
        $start_date = strtotime($date);
        $end_date = strtotime('+'.$_POST['duration'].' day',$start_date);
        $end_date = date('y-m-d',$end_date);
        
        $data=array(
        'course_id' => $_POST['oc_id'],
         'start_date' => $date,
         'end_date' => $end_date,
         'status' => 1
        );
       $updated_table2 = $wpdb->insert( $table2, $data);
        
    }
    
    if($updated_table2)
    {
        return true;
    }else{
        return false;
    }
}
/* Edit Course Section End */

/* Course Selected In "Front-End" Satrt Here */
if(isset($_POST['select_course']) && $_POST['select_course'] === "true")
{
    ob_get_clean();
    select_course($_POST);
}
function select_course()
{
    global $wpdb;
    $id = (int)$_POST['course_id'];  
    $table_name1 = 'wp_offline_courses';
    $table_name2 = 'wp_offline_courses_status';
    $result_oc = $wpdb->get_results("select course_name, location from `$table_name1` where id = $id");
    $result_ocs = $wpdb->get_results("select start_date from `$table_name2` where course_id = $id"); 
    ?>
<form id="book_course_form" method="post">
 <div class="row">
     
    <div class="col-md-6 col-sm-6">
    <input type="text" class="form-control box" placeholder="" name="course_name" value="<?= $result_oc[0]->course_name; ?>" readonly> 
    </div>

    <div class="col-md-6 col-sm-6">
     <input type="text" class="form-control box" name="location" value="<?= $result_oc[0]->location; ?>" readonly>
    </div>

  <div class="col-md-6 col-sm-6">
   <select class="form-control box" name="date">
       <?php foreach($result_ocs as $data_ocs){
        echo '<option value="'.$data_ocs->start_date.'">'.$data_ocs->start_date.'</option>';
        }    ?>
    </select>  
  </div>

  <div class="col-md-6 col-sm-6">
   <input type="text" class="form-control box" placeholder="Full Name" name="full_name" required>
  </div>

  <div class="col-md-6 col-sm-6">
   <input type="text" class="form-control box" placeholder="Job Title" name="job_title" required>  
  </div>

  <div class="col-md-6 col-sm-6">
   <input type="email" class="form-control box" placeholder="Email" name="email" required>
  </div>

  <div class="col-md-6 col-sm-6">
   <input type="text" class="form-control box" maxlength="15" placeholder="Phone" name="phone" required>  
  </div>
     
    <div class="col-md-6 col-sm-6">
        <input type="text" class="form-control box" placeholder="Organization" name="organization" required>
    </div>
     
    <div class="col-md-6 col-sm-6">
        <input type="text" class="form-control box" placeholder="Nationality" name="nationality" required>
    </div>
     
    <div class="col-md-6 col-sm-6">
        <input type="text" class="form-control box" placeholder="Country of Residence" name="country_of_residence" required>
    </div>
     
    <div class="col-md-6 col-sm-6">
        <input type="text" class="form-control box" placeholder="Promotional code" name="promotional_code">
    </div>
     
    <div class="col-md-6 col-sm-6">
        <select class="form-control box" name="where_did_you" required>
            <option selected disabled>Where did you hear about this course</option>
            <option value="Internet search">Internet search</option>
            <option value="Reference from colleague">Reference from colleague</option>
            <option value="Call from SigmaStrat representative">Call from SigmaStrat representative</option>
            <option value="Email from SigmaStrat">Email from SigmaStrat</option>
            <option value="Other.">Other.</option>
        </select>
    </div>

  <div class="col-md-6 col-sm-6">
      <textarea class="form-control box" rows="10" placeholder="Address" name="address"></textarea>
  </div>
     
     <div class="col-md-6 col-sm-6">
         <textarea class="form-control box" rows="10" name="comment_request" placeholder="Message or Request"></textarea>
     </div>
     
 </div><!-- row end here -->
<input type="checkbox" name="terms" value="I Accepted Terms and Conditions" /><a href="#" >Accepted Terms and Conditions</a>
    <center><button class="sign-button1" type="submit">Send</button></center>
</form>
<script>
jQuery(document).ready(function(){
    jQuery("#book_course_form").submit(function(e) {
    e.preventDefault();
    jQuery.ajax({
           type: "POST",
           url: '<?php echo get_site_url(); ?>/wp-content/plugins/Offline_Courses/functions.php',
           data: jQuery("#book_course_form").serialize(),
           success: function(data)
           {
            jQuery(".modal-body").prepend(data);
           }
         });
    });
}); 
</script>
    <?php
}
/* Course Selected In "Front-End" End Here */

/* Mail Selected Course Start Here */
if(isset($_POST['terms']) && !empty($_POST['terms']))
{
    ob_get_clean();
    iqsoft_mail($_POST);
}
function iqsoft_mail()
{
$course_name = $_POST['course_name'];
$date_location = $_POST['date']." And ".$_POST['location'];
$name = $_POST['full_name'];
$job_title = $_POST['job_title'];
$email = $_POST['email'];
$telephone = $_POST['phone'];
$organization = $_POST['organization'];
$address = $_POST['address'];
$comment_request = $_POST['comment_request'];
$term_condition = $_POST['terms'];
$nationality = $_POST['nationality'];
$country_of_residence = $_POST['country_of_residence'];
$promotional_code = $_POST['promotional_code'];
$where_did_you = $_POST['where_did_you'];


$to = 'ankush.iqs@outlook.com';
$subject = 'Book a course';

$message = "Course: ".$course_name."\r\nDate & Location: ".$date_location."\r\n\nFull Name: ".$name."\r\nJob Title: ".$job_title."\r\nEmail ID: ".$email."\r\nPhone: ".$telephone."\r\n\nOrganization: ".$organization."\r\nAddress: ".$address."\r\nCountry of Residence: ".$country_of_residence."\r\nNationality: ".$nationality."\r\n\nPromo Code: ".$promotional_code."\r\nWhere did you hear about this course : ".$where_did_you."\r\nMessage/Request: ".wordwrap($comment_request, 70, "\r\n")."\r\n".$term_condition;

$headers = 'From: info@sigmastrat.com' . "\r\n" .'Reply-To: '.$email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();

//$message = wordwrap($message, 70, "\r\n");

if(mail($to, $subject, $message, $headers))
{
    ?>
        <div class="alert alert-info">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                ×</button>
            <span class="glyphicon glyphicon-info-sign"></span> <strong>Thanks! Message Sent Successfully.</strong>
            <hr class="message-inner-separator">
            <p>We will in touch soon.</p>
        </div>
    <?php
}
else
{
    ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                ×</button>
            <span class="glyphicon glyphicon-info-sign"></span> <strong>Sorry! Message Not Sent.</strong>
            <hr class="message-inner-separator">
            <p>Unknown error ocurred.</p>
        </div>
    <?php
}
}
/* Mail Selected Course Start Here */
?>
