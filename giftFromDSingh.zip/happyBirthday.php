<?php 

class happyBirthday {

	public $birthdayBoyMsg;

	public function __construct( $birthdayBoy ){

		$this->birthdayBoyMsg = <<<EOT
		<h1><center><q> 
		तुम जियो हजारों साल
		<br>
		साल के दिन हो पचास हज़ार 
		</q></center></h1>
		<br><br>
		<p><center><i>इक्विनेसॉफ्ट के हमारे प्यारे राजदुलारे नाहने मुन्ने JCB जैसे  जुझारू कर्मठ निष्ठावान निर्भीक धाकड़ छोरा <strong>$birthdayBoy</strong> को उनके जन्मदिन की हार्दिक सुभकामनाएँ !</i></center></p>
		EOT;
	}
}
$wishUhappyBDay = new happyBirthday('नरेंद्र बाबू');

echo $wishUhappyBDay->birthdayBoyMsg;

?>