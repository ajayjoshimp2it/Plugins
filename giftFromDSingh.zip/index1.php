<?php
class birthDayWishes
{	

	protected $wishingFor = $array  = array( 'S', array( 'H', array('R', array('D') ) ), 'A', array(' ', 'G', array('U', array('P')),'T' ), 'A' );

	static public function partyPerson($wishingFor){

		for( $i = 0; $i < count($wishingFor); $i++ ){

			if( is_array($wishingFor[$i]) ){

			 array_splice( $wishingFor,$i,1,$wishingFor[$i] );
			 $i = 0;

			}
		}

		$wishingTo = implode( $wishingFor );

		_e( 'आपको अपने जन्मदिन की बहुत बहुत हार्दिक शुभकामनाएं '.$wishingTo, 'wp-birthday-domain' );

	}

}

add_action( 'wp_Developer_Birthday', 'birthDayWishes::partyPerson' );

?>