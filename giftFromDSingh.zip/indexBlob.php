<?php
if(isset($_POST['submit'])):
$tmp_name = $_FILES['file']['tmp_name'];
$photo = base64_encode(fread(fopen($tmp_name, "r"),$_FILES["file"]["size"]));
echo $photo;
?>
<img src="<?= 'data:image/jpg;base64,'.$photo; ?>">
<?php
endif;
?>
<form action="<?= $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="file">
    <br>
    <input type="submit" name="submit">
</form>