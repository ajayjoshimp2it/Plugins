<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "albany";
$db_user = 'albany_albany';
$db_name = 'albany_albany';
$db_pass = '89arlva6skeKWILXM1';
// Create connection
$conn = new mysqli($server, $user, $pass,$db);
/*$conn = new mysqli($server, $db_user, $db_pass ,$db_name);*/

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
date_default_timezone_set("Asia/Kolkata");
//SQL query argument
$sql = "SELECT 
				event_attendees_dt.atnd_email,
				location.loc_description
				FROM event 
				INNER JOIN event_attendees_hd 
				ON event.id = event_attendees_hd.atnd_evt_id
				INNER JOIN event_attendees_dt
				ON event_attendees_hd.id = event_attendees_dt.atnd_hd_id
				INNER JOIN location
				ON event.evt_locid = location.id
				WHERE TIMESTAMPDIFF(HOUR,event.evt_endtime, CURRENT_TIMESTAMP()) = 2";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($data = $result->fetch_assoc()) {
			$to = $data['atnd_email'];
			$adminEmail = "info@AlbanyPineBush.org";
			$errSubject = 'Albany Pine Bush Event Email "'.$data['atnd_email'].'" Not Delivered';
			$subject = "Albany Pine Bush Event Notification";
			$message = "
			We hope you enjoyed your visit to the Albany Pine Bush Preserve.
			<br>
			Please help us in evaluating our programs, special events and services by providing your feedback.
			<br> 
			Click here [<a href='http://fs12.formsite.com/apbpc/form6/index.html' target='_blank' >http://fs12.formsite.com/apbpc/form6/index.html</a>] to answer a few questions. 
			This short survey should only take a few minutes.
			<br>
			Want to email your feedback?
			<br>
			<a href='mailto:info@AlbanyPineBush.org' >info@AlbanyPineBush.org</a>
			<br>
			Need to speak to someone? <a href='tel:5184560655' >518-456-0655</a>
			<br>
			Albany Pine Bush Preserve Commission
			<br>
			195 New Karner Road
			<br>
			Albany, NY 12205
			<br>
			<a href='albanyPineBush.org' target='_blank'>AlbanyPineBush.org</a>
			<br>
			-----------------------------------------------------------------------------------------------------
			</body>
			</html>
			";
			/*echo $message;*/			
			echo $data['loc_description'];die();
			/*$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= 'From: <info@jjcbigideas.com>';
			if(!mail($to,$subject,$message,$headers)){
				mail($adminEmail,$errSubject,$message,$headers);
			}*/
    }	
} else {
    exit();
}
$conn->close();
?>