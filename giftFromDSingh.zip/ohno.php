<?php
function listFolderFiles($dir){
    $root = scandir($dir,false);
    unset($root[array_search('.', $root, true)]);
    unset($root[array_search('..', $root, true)]);
    /*echo "<pre>";
    print_r($root);die;*/

    // prevent empty ordered elements
    if (count($root) < 1)
        return;

    echo '<ol>';
    foreach($root as $ff){
        echo '<li><a href="'.$ff.'">'.$ff;
        /*if(is_dir($dir.'/'.$ff))
        { 
            listFolderFiles($dir.'/'.$ff);
        }*/
        echo '</a></li>';
    }
    echo '</ol>';
}

listFolderFiles('./mohawk/');

/*function dirToArray($dir) { 
   
   $result = array(); 

   $cdir = scandir($dir); 
   foreach ($cdir as $key => $value) 
   { 
      if (!in_array($value,array(".",".."))) 
      { 
         if (is_dir($dir . DIRECTORY_SEPARATOR . $value)) 
         { 
            $result[$value] = dirToArray($dir . DIRECTORY_SEPARATOR . $value); 
         } 
         else 
         { 
            $result[] = $value; 
         } 
      } 
   } 
   
   return $result; 
} 
echo "<pre>";
print_r(dirToArray('./'));*/
?>

