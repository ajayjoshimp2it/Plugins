<?php 
$data = Array(
    "country" => null,
    "udf10" => null,
    "discount" => "0.00",
    "cardToken" => "5305cf28befd119c4afae",
    "mode" => "CC",
    "cardhash" => "This field is no longer supported in postback params.",
    "error_Message" => "No Error",
    "state" => null,
    "bankcode" => "CC",
    "txnid" => "520433232799422",
    "surl" => "http://ldrfoundation.com/test.php",
    "net_amount_debit" => "10",
    "lastname" => null,
    "zipcode" => null,
    "phone" => "7906677087",
    "productinfo" => "Payment made for LDR HUMANIZING FOUNDATION",
    "hash" => "82b21d799edaa847d358a809b0381a0b06e8561b7120963a78c71060c7cf201ce8cca8391d4e593d9546bfddd0eacc68fa2311adc6a08f462b14a7163fc98660",
    "status" => "success",
    "firstname" => null,
    "city" => null,
    "isConsentPayment" => "0",
    "error" => "E000",
    "addedon" => "2019-02-23 09:45:39",
    "udf9" => null,
    "udf7" => null,
    "udf8" => null,
    "encryptedPaymentId" => "833A29CCC5EB17E98985EBF256FAAD24",
    "bank_ref_num" => "905418003570",
    "key" => "SfxLv9Ou",
    "email" => "cadharm91@gmail.com",
    "amount" => "10.00",
    "unmappedstatus" => "captured",
    "address2" => null,
    "payuMoneyId" => "232799422",
    "address1" => null,
    "udf5" => null,
    "mihpayid" => "8068099385",
    "udf6" => null,
    "udf3" => null,
    "udf4" => null,
    "udf1" => null,
    "udf2" => null,
    "field1" => null,
    "cardnum" => "517252XXXXXX9453",
    "field7" => null,
    "field6" => "140201905447669783",
    "furl" => "http://ldrfoundation.com/test.php",
    "field9" => "Transaction Completed Successfully",
    "field8" => null,
    "amount_split" => null,
    "field3" => null,
    "field2" => "R73786",
    "field5" => "201905452286053",
    "PG_TYPE" => "UBIFSSPG",
    "field4" => null,
    "name_on_card" => "RatanSingh",
    "txnStatus" => "SUCCESS",
    "txnMessage" => "Transaction Successful"
);
?>
<!doctype html>
<html>

<head>
	<meta charset="utf-8">
	<title>Invoice</title>
	<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>-->
	<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/printThis/1.14.0/printThis.min.js"></script>
</head>

<body>
	<div id="nodeToRenderAsPDF" style="max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0, 0, 0, .15);height: 620px; font-size: 16px; line-height: 24px; font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif; color: #555;">
		<table cellpadding="0" cellspacing="0" style="width: 100%; line-height: inherit; text-align: left;" width="100%" align="left">
			<tr>
				<td colspan="2" style="padding: 5px; vertical-align: top;" valign="top">
					<table style="width: 100%; line-height: inherit; text-align: left;" width="100%" align="left">
						<tr>
							<td style="padding: 5px; vertical-align: top; padding-bottom: 20px; font-size: 45px; line-height: 45px; color: #333;" valign="top"> <img src="http://ldrfoundation.com/assets/img/logo.png" style="width:100%; max-width:130px;"> </td>
							<td style="padding: 5px; vertical-align: top; text-align: right; padding-bottom: 20px;" valign="top" align="right"> Transaction ID#:
								<?=$data['txnid']; ?><br>Date:
								<?php echo date('d M Y',strtotime($data['addedon'])); ?><br>Time:
								<?php echo date('h:i A',strtotime($data['addedon'])); ?>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="padding: 5px; vertical-align: top;" valign="top">
					<table style="width: 100%; line-height: inherit; text-align: left;" width="100%" align="left">
						<tr>
							<td style="padding: 5px; vertical-align: top; padding-bottom: 40px;" valign="top"> Office no 211, G-79-80,<br>Gupta Complex, Nr Metro Pillar no 37-38,<br>Main Market Laxmi Nagar, delhi-110092 </td>
							<td style="padding: 5px; vertical-align: top; text-align: right; padding-bottom: 40px;" valign="top" align="right"> Ratan Singh<br>Call: 011-42401380<br>E-mail: ratan@ldrgroups.com </td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top; background: #eee; border-bottom: 1px solid #ddd; font-weight: bold;" valign="top"> Payment Detail </td>
				<td style="padding: 5px; vertical-align: top; text-align: right; background: #eee; border-bottom: 1px solid #ddd; font-weight: bold;" valign="top" align="right">
					<?=$data['productinfo']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top;" valign="top">Name:</td>
				<td style="padding: 5px; vertical-align: top; text-align: right;" valign="top" align="right">
					<?=$data['name_on_card']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top;" valign="top">Card No.:</td>
				<td style="padding: 5px; vertical-align: top; text-align: right;" valign="top" align="right">
					<?=$data['cardnum']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top;" valign="top">Email:</td>
				<td style="padding: 5px; vertical-align: top; text-align: right;" valign="top" align="right">
					<?=$data['email']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top; padding-bottom: 20px;" valign="top">Phone:</td>
				<td style="padding: 5px; vertical-align: top; text-align: right; padding-bottom: 20px;" valign="top" align="right">
					<?=$data['phone']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top; background: #eee; border-bottom: 1px solid #ddd; font-weight: bold;" valign="top">Donation</td>
				<td style="padding: 5px; vertical-align: top; text-align: right; background: #eee; border-bottom: 1px solid #ddd; font-weight: bold;" valign="top" align="right"></td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top; border-bottom: none;" valign="top"> Raising Funds for the families of Martyres of Pulwama Terrorist Attack </td>
				<td style="padding: 5px; vertical-align: top; text-align: right; border-bottom: none;" valign="top" align="right">&#8377;
					<?=$data['amount']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top; border-bottom: none;" valign="top">Status</td>
				<td style="padding: 5px; vertical-align: top; text-align: right; border-bottom: none; font-weight:700" valign="top" align="right">
					<?=$data['txnStatus']; ?>
				</td>
			</tr>
			<tr>
				<td style="padding: 5px; vertical-align: top;" valign="top"></td>
				<td style="padding: 5px; vertical-align: top; text-align: right; border-top: 2px solid #eee; font-weight: bold;" valign="top" align="right">
					<?=$data['txnMessage']; ?> of &#8377;
					<?=$data['amount']; ?>
				</td>
			</tr>
		</table>
	</div>
	<button style="text-align:center;margin-left:40%" onclick="print()">Print</button>
</body>

</html>
<?php $file_name = "invoice".$data['payuMoneyId'].".pdf"; ?>
<script>
function print(){	
$("#nodeToRenderAsPDF").printThis({
    debug: false,               // show the iframe for debugging
    importCSS: true,            // import parent page css
    importStyle: true,         // import style tags
    printContainer: true,       // print outer container/$.selector
    loadCSS: "",                // path to additional css file - use an array [] for multiple
    pageTitle: "Invoice",              // add title to print page
    removeInline: false,        // remove inline styles from print elements
    removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
    printDelay: 333,            // variable print delay
    header: null,               // prefix to html
    footer: null,               // postfix to html
    base: false,                // preserve the BASE tag or accept a string for the URL
    formValues: true,           // preserve input/form values
    canvas: false,              // copy canvas content
    doctypeString: '...',       // enter a different doctype for older markup
    removeScripts: false,       // remove script tags from print content
    copyTagClasses: false,      // copy classes from the html & body tag
    beforePrintEvent: null,     // function for printEvent in iframe
    beforePrint: null,          // function called before iframe is filled
    afterPrint: null            // function called before iframe is removed
});
}
</script>
<!--<script>
function print() {
		const filename  = '<?php //echo $file_name ?>';

		html2canvas(document.getElementById('nodeToRenderAsPDF'), 
								{scale: 1}
						 ).then(canvas => {
			let pdf = new jsPDF('p', 'mm', 'a4');
			pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, 211, 298);
			pdf.save(filename);
		});
	}
</script>-->