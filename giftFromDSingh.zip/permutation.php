<?php 
$collect = null;
$arr = str_split('ABCDE');
$len = count($arr)-1;
depth_picker( $arr, '', $collect, $len );

function depth_picker($arr, $temp_string, $collect,$len) {
    if ($temp_string != "") {
        $collect[] = $temp_string;

    }

    for ($i=0, $iMax = sizeof($arr); $i < $iMax; $i++) {

        $arrcopy = $arr;
        $elem = array_splice($arrcopy, $i, 1);
        if (sizeof($arrcopy) > 0) {
            depth_picker($arrcopy, $temp_string ." " . $elem[0], $collect,$len);
        } else {
            $collect[] = $temp_string. " " . $elem[0];
            echo '<pre>';	
        print_r($collect[$len]); 
        }   
    }   
}
?>                                                                      