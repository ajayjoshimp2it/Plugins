<ul style="list-style:none;">
<?php
$files = new RecursiveIteratorIterator (new RecursiveDirectoryIterator('./images/'), RecursiveIteratorIterator::LEAVES_ONLY);
foreach($files as $data)
{
    if(is_dir($data) != true)
    {
    $olddata = $data;   
    $tempdata = explode('\\',$data); 
    $length = count($tempdata);
    echo "<li>".$tempdata[$length-1]."</li>";    
    /*$tempdata[$length-1] = "./images\\".str_replace(" ","_",$tempdata[$length-1]);
    rename($olddata,$tempdata[$length-1]);  */  
    /*$data = implode('\\',$tempdata);
    rename($olddata,$data);
    echo $olddata."<br>";
    echo $data."<br><br>"; */
    }
}
    /*echo "<br>Done";*/
?>
    
</ul>    




