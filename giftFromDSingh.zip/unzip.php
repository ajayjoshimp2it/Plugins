<?php
$zip = new ZipArchive;
$res = $zip->open('upload-me.zip');
if ($res === TRUE) {
  $zip->extractTo('./');
  $zip->close();
  echo 'Ho Gaya Babu Moshaye';
} else {
  echo 'Dhat Tere ki File nahi mili';
}
?>