<?php
function recentPosts() {
	    $rPosts = new WP_Query();
	    $rPosts->query('showposts=3');
	        while ($rPosts->have_posts()) : $rPosts->the_post(); ?>
			   <div class="col-md-4 col-sm-4">

	       <div class="effect item"> <?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post_ids[$i] ), 'tumba');// print get_the_post_thumbnail($post_ids[$i], 'medium', array( 'class' => 'img-responsive')); ?>

<a href="<?php print get_permalink($post_ids[$i]); ?>"><img class="img-responsive blogggg"  alt="blog"  src="<?php echo $large_image_url[0];  ?>" />
 </a>
 <div class="item-overlay top"></div>
</div>
		       <div class="blog_main">
			<span class="colr">	<?php the_time( get_option( 'date_format' ) ); ?></span>
<a href="<?php the_permalink(); ?>"><h4><?php the_title();?></h4></a>
<?php echo substr(get_the_content(),0, 190); ?>...

      <div class="row">
      <div class="col-md-6 col-sm-6 col-xs-6">
       <div class="read_btn" ><a href="<?php the_permalink();?>"> Read More</a></div>
      </div><!-- col end here --> 
      
      <div class="col-md-6 col-sm-6">
      <a href="https://www.facebook.com/raghav.parkash" target="blank"><i class="fa fa-facebook"></i></a>
      <a href="https://twitter.com/raghavparkash" target="_blank"><i class="fa fa-twitter"></i></a>
      <a href="https://www.youtube.com/channel/UC7F5sJJ9jj0pZ0euUnraiIw" target="_blank"><i class="fa fa-youtube-play"></i></a>
      <a href="https://www.instagram.com/raghavparkash/"  target="_blank"><i class="fa fa-instagram"></i></a>
      <a href="https://uk.linkedin.com/in/raghavparkash" target="_blank"><i class="fa fa-linkedin"></i></a>
      </div>
     </div>
	 </div>
	 </div>
<?php endwhile;
	    wp_reset_query();
	}
?>





















/*   call the content in page.php         */
<?php
	 while(have_posts()):the_post();
	 the_content();
	 endwhile;
?>


/* add widget in function.php */
function twentyfifteen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Widget Area', 'twentyfifteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentyfifteen' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'twentyfifteen_widgets_init' );


/*   to call widget in page  */

<?php dynamic_sidebar( 'sidebar-1' ); ?>





/*code for post on the page with category */
	<?php
	$args = array( 'category' => 4, 'post_type' =>  'post' ); 
	$postslist = get_posts( $args );    
	foreach ($postslist as $post) :  setup_postdata($post); 
	?> 
	<?php the_post_thumbnail(array(360, 207), array( 'class' => 'img-responsive' ));?>
							<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							<?php echo substr(get_the_excerpt(),0,200); ?> 
							    
    <?php endforeach; ?>  
/*end of the code */

/*code for the post without category */
						<?php
						$id=95;
						$post = get_post($id); 
						setup_postdata($post);
						?>
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(array(360, 207), array( 'class' => 'img-responsive' ));?></a>
						<?php print date('F d Y' ,get_post_time( )); ?> <br>
						<?php echo substr(get_the_excerpt(),0,100); ?> 
						
/*end of the code*/

/*code for archive in the page*/
<?php $args = array(
		'type'            => 'monthly',
		'limit'           => '',
		'format'          => 'html', 
		'before'          => '<span> >> </span>',
		'after'           => '',
		'show_post_count' => false,
		'echo'            => 1,
		'order'           => 'DESC'
		);
		wp_get_archives( $args ); 
		?>
also make a file with the name of Archive.php
/*end of the code*/		
/* register menu */

<?php register_nav_menu('menu', 'primary menu'); ?>

/* register menu  ends*/

/*menu dynamic without dropdown*/

<?php $items = wp_get_nav_menu_items('menu' );
      foreach ($items as $val){
       echo '<li id="menu-' . $val->post_excerpt . '"><a href="'.$val->url.'">'.$val->title.'</a></li>';
      }
?>
/*menu dynamic without dropdown end*/

/*menu dynamic with dropdown*/

	<?php 
	$items=wp_get_nav_menu_items( 'iq-hmenu' );

	foreach ($items as $val)
	{
	if($val->menu_item_parent==0){
	$arr1[]=$val;
}
else{
$arr2[$val->menu_item_parent][]=$val;
}
}
foreach($arr1 as $val){
if (array_key_exists($val->ID,$arr2))
{
echo '<li class="dropdown">
<a href="'.$val->url.'" class="dropdown-toggle" data-toggle="">'.$val->title.' <b class="caret"></b></a><ul class="dropdown-menu">';
foreach($arr2[$val->ID] as $val2) {
echo '<li id="menu-' . $val2->post_excerpt . '"><a href="'.$val2->url.'">'.$val2->title.'</a>'; 
};
echo '</ul>
</li>';
}
else
{
echo '<li id="menu-' . $val->post_excerpt . '"><a href="'.$val->url.'">'.$val->title.'</a>
</li>';
}
}
?>

/*menu dynamic with dropdown ends*/

/*to call the content of post,custom post or page*/

<?php while(have_posts()):the_post();
the_content();					
endwhile;
?>

/*to call the content of post,custom post or page ends*/


/* for adding active class*/

<?php 
  global $post;
  $slug = $post->post_name;
 ?>
 <script type="text/javascript">
  $(document).ready(function(){
   $('#menu-<?php print $slug; ?>').addClass('active');
  }); 
 </script>

<script src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"></script>
     <?php global $post;
    $slug = get_post($post)->post_name; //echo $slug;?>
    <script type="text/javascript">
      $(document).ready(function(){ 
      $("#menu-<?php echo $slug; ?>").addClass('active');
      });
   </script>

/* for active ends*/

/*register widget*/

<?php if(function_exists('register_sidebar')) 
{ register_sidebar(array('name'=>'widgets_name'));}
?>


/*register widget ends*/

/*show post on the basis of category id*/

<?php
    $args = array( 'category' => 15, 'post_type' =>  'post' ); 
    $postslist = get_posts( $args );    
    foreach ($postslist as $post) :  setup_postdata($post); 
    ?>  
    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2> 
    <?php the_excerpt(); ?>  
    <?php endforeach; ?>

/*show post on the basis of category id ends*/


/*set the length of the content of blog to be display */
<?php
	$content = get_the_content();s
$content = strip_tags($content);
echo substr($content, 0, 50);
?>	

/*set the length of the content of blog to be display ends*/


/* to insert widget in wordpress*/
<?php register_sidebar(array('name'=>'blog'));?>

/* to insert widget in wordpress ends*/


/*insert a menus bar in wordpress*/

<?php register_nav_menu('menus','primary menu');?>

/*insert a menus bar in wordpress*/



/* insert any plugin in wordpress*/

<?php echo do_shortcode('shortcode')?>

/* insert any plugin in wordpress ends*/



/* code for display number of post on wb page */

<ul>
    <?php $the_query = new WP_Query( 'showposts=2' ); ?>

    <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
    <li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>

    <li><?php the_excerpt(__('(more…)')); ?></li>
    <?php endwhile;?>
    </ul>

/*coed for display number of pages ends*/

*******code for wp_nav_menu ul class*/

<?php wp_nav_menu( array( 'items_wrap' => '<ul class="sf-menu">%3$s' ) ); ?>

/*code for wp_nav_menu ul class ends*/


*********code for add thumbnail in wordpress*******

add_theme_support('post-thumbnails', array('post', 'book'));
************************************************************

/*img-responsive thumbnail size display*/

<?php
    if ( has_post_thumbnail() ) {
    the_post_thumbnail(array(1024, 512), array('class' => 'img-responsive')); 
        }
    ?>
/*end img-responsive thumbnail size display*/


*************************************************

1. ragister widgets in function.php with this code .

/*this code put in the function.php*/

<?php if(function_exists('register_sidebar')) 
{ register_sidebar(array('name'=>'widgets_name'));}
?>
2. now this widgets has placed in widgets.

3. now u can add code for widgets(to make this).
4. now placed widgets dynamic code into the location where u want placed it(file).
/*this code put in the calling place*/
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('widgets_name') ) : endif; ?>

*************************************************

*************************************************
if we are using multilingual plugin,code for the home page titles code

<?php print ppqtrans_useCurrentLanguageIfNotFoundUseDefaultLanguage('[:en]Latest News[:ar]??? ???????'); ?>

*************************************************
how to make dynamic header photo(this code is for when the header image comes from the CSS code.)
step-1-
place this code in the function.php

add_theme_support( 'custom-header' );
$defaults = array(
	'default-image'			 => get_template_directory_uri() . '/images/header.jpg',
	'width'         		 => 1140,
	'height'        		 => 345,
	'flex-width'    		 => true,
	'flex-height'   		 => true,
	'uploads'                => true,
	'random-default'         => false,
	'header-text'            => true,
	'default-text-color'     => '',
	'wp-head-callback'       => '',
	'admin-head-callback'    => '',
	'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $defaults );
 ?>
 step-2-
 
 place this code in the header.php
 <style>
			.intro-header {
				background: url("<?php header_image(); ?>") no-repeat scroll center center / cover rgba(0, 0, 0, 0);
				color: #f8f8f8;
				height: <?php echo get_custom_header()->height; ?>px;			
				text-align: center;
			}
		</style>

*******************************************
*******************************************
code for make the dynamic logo of the website.
1. you have to download Manage Site Logo plugin(https://wordpress.org/plugins/website-logo/screenshots/)
2.place the shotcode from where the logo comes.

*******************************************

*******************************************
code for multiple location marker on the google map
1.you have to download easy2map plugin(https://wordpress.org/plugins/easy2map/screenshots/)
2.place the short code where you want the map. 

*******************************************
code for dynamic dropdown menu
1. paste this code where the menu to be shown

<?php  
								$menu_args = array(
								'menu'            => 'Header_menu', 
								'container'       => 'container', 
								'container_class' => 'container_class', 
								'container_id'    => 'container_id',
								'menu_class'      => '',     /*class of the style of html*/
								'menu_id'         => '',
								'echo'			=> true,
								'walker'			=>	new BootstrapNavMenuWalker()
								 );
								wp_nav_menu( $menu_args );
							?> 			

2. paste this code in the functions.php

<?php
/**
 * Extended Walker class for use with the
 * Twitter Bootstrap toolkit Dropdown menus in Wordpress.
 * Edited to support n-levels submenu.
 * @author johnmegahan https://gist.github.com/1597994, Emanuele 'Tex' Tessore https://gist.github.com/3765640
 * @license CC BY 4.0 https://creativecommons.org/licenses/by/4.0/
 */
class BootstrapNavMenuWalker extends Walker_Nav_Menu {
	function start_lvl( &$output, $depth ) {
		$indent = str_repeat( "\t", $depth );
		$submenu = ($depth > 0) ? ' sub-menu' : '';
		$output	   .= "\n$indent<ul class=\"dropdown-menu$submenu depth_$depth\">\n";
	}
	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		$li_attributes = '';
		$class_names = $value = '';
		$classes = empty( $item->classes ) ? array() : (array) $item->classes;
		
		// managing divider: add divider class to an element to get a divider before it.
		$divider_class_position = array_search('divider', $classes);
		if($divider_class_position !== false){
			$output .= "<li class=\"divider\"></li>\n";
			unset($classes[$divider_class_position]);
		}
		
		$classes[] = ($args->has_children) ? 'dropdown' : '';
		$classes[] = ($item->current || $item->current_item_ancestor) ? 'active' : '';
		$classes[] = 'menu-item-' . $item->ID;
		if($depth && $args->has_children){
			$classes[] = 'dropdown-submenu';
		}
		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
		$class_names = ' class="' . esc_attr( $class_names ) . '"';
		$id = apply_filters( 'nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args );
		$id = strlen( $id ) ? ' id="' . esc_attr( $id ) . '"' : '';
		$output .= $indent . '<li' . $id . $value . $class_names . $li_attributes . '>';
		$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
		$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
		$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
		$attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';
		$attributes .= ($args->has_children) 	    ? ' class="dropdown-toggle" data-hover="dropdown"' : '';
		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'>';
		$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
		$item_output .= ($depth == 0 && $args->has_children) ? ' <b class="caret"></b></a>' : '</a>';
		$item_output .= $args->after;
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
	
	function display_element( $element, &$children_elements, $max_depth, $depth=0, $args, &$output ) {
		//v($element);
		if ( !$element )
			return;
		$id_field = $this->db_fields['id'];
		//display this element
		if ( is_array( $args[0] ) )
			$args[0]['has_children'] = ! empty( $children_elements[$element->$id_field] );
		else if ( is_object( $args[0] ) )
			$args[0]->has_children = ! empty( $children_elements[$element->$id_field] );
		$cb_args = array_merge( array(&$output, $element, $depth), $args);
		call_user_func_array(array(&$this, 'start_el'), $cb_args);
		$id = $element->$id_field;
		// descend only when the depth is right and there are childrens for this element
		if ( ($max_depth == 0 || $max_depth > $depth+1 ) && isset( $children_elements[$id]) ) {
			foreach( $children_elements[ $id ] as $child ){
				if ( !isset($newlevel) ) {
					$newlevel = true;
					//start the child delimiter
					$cb_args = array_merge( array(&$output, $depth), $args);
					call_user_func_array(array(&$this, 'start_lvl'), $cb_args);
				}
				$this->display_element( $child, $children_elements, $max_depth, $depth + 1, $args, $output );
			}
			unset( $children_elements[ $id ] );
		}
		if ( isset($newlevel) && $newlevel ){
			//end the child delimiter
			$cb_args = array_merge( array(&$output, $depth), $args);
			call_user_func_array(array(&$this, 'end_lvl'), $cb_args);
		}
		//end this element
		$cb_args = array_merge( array(&$output, $element, $depth), $args);
		call_user_func_array(array(&$this, 'end_el'), $cb_args);
	}
}


/*dyanmic drop down menu*/
<?php $defaults = array(
    'theme_location'  => ,
    'menu'            => ,
    'container'       => 'div',
    'container_class' => 'menu-{menu slug}-container',
    'container_id'    => ,
    'menu_class'      => 'menu',
    'menu_id'         => ,
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => ,
    'after'           => ,
    'link_before'     => ,
    'link_after'      => ,
    'items_wrap'      => '<ul id=\"%1$s\" class=\"%2$s\">%3$s</ul>',
    'depth'           => 0,
    'walker'          =>
);
?>
 
<?php wp_nav_menu( $defaults ); ?>





    
/* dyanmic drop down menu */
		 <?php $items=wp_get_nav_menu_items( 'main_menu' );							  
							   foreach ($items as $val)
							   { 
									if($val->menu_item_parent==0){
										$arr1[]=$val; 						
									}
									else{
									$arr2[$val->menu_item_parent][]=$val;
									}											   
							   }
						   foreach($arr1 as $val){							  
							  if (array_key_exists($val->ID,$arr2))
							   {
								echo '<li class="dropdown">
								<a href="'.$val->url.'" class="dropdown-toggle" data-toggle="dropdown">'.$val->title.' </a><ul class="dropdown-menu">';
								foreach($arr2[$val->ID] as $val2) {
									echo '<li id="menu-' . $val2->post_excerpt . '"><a href="'.$val2->url.'">'.$val2->title.'</a>';
								};								  
							echo '</ul>
								</li>';
								   }
								else
								   {								 
							    echo '<li id="menu-' . $val->post_excerpt . '"><a href="'.$val->url.'">'.$val->title.'</a>
							   </li>';
							   }
							   }
	

/* custom meta box */ 
in function.php


function wporg_add_custom_box()
{
    $screens = ['post', 'wporg_cpt'];
    foreach ($screens as $screen) {
        add_meta_box(
            'wporg_box_id',           // Unique ID
            'Custom Meta Box Title',  // Box title
            'wporg_custom_box_html',  // Content callback, must be of type callable
            $screen                   // Post type
        );
    }
}
add_action('add_meta_boxes', 'wporg_add_custom_box');


function wporg_custom_box_html($post)
{
    $value = get_post_meta($post->ID, '_wporg_meta_key', true);
    ?>
    <label for="wporg_field">Name:</label>
  <input type="text" name="wporg_field" id="wporg_field" class="postbox">
    <?php
}

function wporg_save_postdata($post_id)
{
    if (array_key_exists('wporg_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_wporg_meta_key',
            $_POST['wporg_field']
        );
    }
}
add_action('save_post', 'wporg_save_postdata');



************and*********** in either index,page,single depend on theme.

 // Retrieves the stored value from the database
    $meta_value = get_post_meta( get_the_ID(), '_wporg_meta_key', true );
 
    // Checks and displays the retrieved value
    if( !empty( $meta_value ) ) {
        echo $meta_value;
    }



???????????????? for creating shortcode ?????????????
	
	 add_shortcode('first', 'wp_first_shortcode');




	 ********* custom post type in function.php **************/

	 add_action( 'init', 'create_news_and_updates' );
	function create_news_and_updates() {

    register_post_type( 'videos',
        array(
            'labels' => array(
                'name' => 'Videos',
                'singular_name' => 'News Videos',
				'add_new' => 'Add New Video',
                'add_new_item' => 'Add New Video',
                'edit' => 'Edit',
                'edit_item' => 'Edit Videos',
                'new_item' => 'New Videos',
                'view' => 'View',
                'view_item' => 'View News Videos',
				'all_items' =>'All Videos',
                'search_items' => 'Search News Videoss',
                'not_found' => 'No News Videoss found',
                'not_found_in_trash' => 'No News Videoss found in Trash',
                'parent' => 'Parent News Videos'
            ), 
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => 'https://99creativewebsite.co.in/bible/wp-content/uploads/2017/02/news2.png',
            'has_archive' => true
        )
    ); 
} 
 add_action( 'init', 'create_news_taxonomies', 0 );  
	function create_news_taxonomies() {
    register_taxonomy(
        'videos_cat',
        'videos',
        array(
            'labels' => array(
                'name' => 'Videos category',
                'add_new_item' => 'Add New category',
                'new_item_name' => "New Offer Type Genre"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'hierarchical' => true
			)
    );
}

************* in index.php **********************
 $mypost = array( 'post_type' => 'videos','videos_cat'=>'bhajan', );
    $loop = new WP_Query( $mypost );
     while ( $loop->have_posts() ) : $loop->the_post();



	 the_post_thumbnail( array( 100, 100 ) ); 
	 echo esc_html( get_post_meta( get_the_ID(), 'Youtube _link', true ) ); 
	  the_title();
						
	 endwhile; 
    wp_reset_query();

 /********* custom post type Services **************/

    add_action( 'init', 'create_custom_post_type_Services' );
	function create_custom_post_type_Services() {

    register_post_type( 'Services',
        array(
            'labels' => array(
                'name' => 'Services',
                'singular_name' => 'News Services',
				'add_new' => 'Add New Service',
                'add_new_item' => 'Add New Service',
                'edit' => 'Edit',
                'edit_item' => 'Edit Services',
                'new_item' => 'New Services',
                'view' => 'View',
                'view_item' => 'View News Services',
				'all_items' =>'All Services',
                'search_items' => 'Search News Services',
                'not_found' => 'No News Services found',
                'not_found_in_trash' => 'No News Services found in Trash',
                'parent' => 'Parent News Videos'
            ), 
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => 'https://99creativewebsite.co.in/bible/wp-content/uploads/2017/02/news2.png',
            'has_archive' => true
        )
    ); 
} 


 add_action( 'init', 'create_Services_taxonomies', 0 );  
	function create_Services_taxonomies() {
    register_taxonomy(
        'Service_cat',
        'Services',
        array(
            'labels' => array(
                'name' => 'Services category',
                'add_new_item' => 'Add New category',
                'new_item_name' => "New Offer Type Genre"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'hierarchical' => true
			)
    );
}
/* menu starts  */

<?php 
                                      $defaults = array(     
                                          'theme_location'  => '',    
                                          'menu'            => 'Main_Menu',   
                                          'container'       => '',     
                                          'container_class' => '',     
                                          'container_id'    => '',   
                                          'menu_class'      => 'menu',   
                                          'menu_id'         => '',   
                                          'echo'            => true,
                                          'fallback_cb'     => 'wp_page_menu',
                                          'before'          => '',     
                                          'after'           => '',    
                                          'link_before'     => '',
                                          'link_after'      => '',    
                                          'items_wrap'      => '%3$s',    
                                          'depth'           => 0    
                                         );  
                                         wp_nav_menu($defaults); 
                                     ?>
<!--menu ends-->