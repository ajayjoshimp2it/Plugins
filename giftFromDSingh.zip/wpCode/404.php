<?php
get_header(); ?>
//Set the layout for message.
<?php get_search_form(); ?>

<?php get_footer(); ?>
#fdecce