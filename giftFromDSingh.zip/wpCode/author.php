<?php get_header(); ?>
<div class="banner"></div>
<?php
$curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
?>
<div class="about_txt">
    <h1>
        <?php echo $curauth->nickname; ?>
    </h1>
</div>
<div class="tips_section">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-8">
                <h2>Website:</h2><a href="<?php echo $curauth->user_url; ?>"><?php echo $curauth->user_url; ?></a>
                <br><h2>Profile</h2><p><?php echo $curauth->user_description; ?></p>
                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

                <div class="row">
                    <div class="col-md-6 col-sm-6">
                        <div class="effect">
                            <?php if (has_post_thumbnail()): ?>
                            <a href="<?= the_permalink() ?>"><?php the_post_thumbnail('full', array('class'=> 'img-responsive imagee')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- col end here -->

                    <div class="col-md-6 col-sm-6">
                        <h4><a href="<?= the_permalink() ?>">
                            <?= the_title() ?>
                            </a>
                        </h4>
                        <p>
                            <?= substr( strip_tags( get_the_excerpt() ),0,200); ?>
                        </p>
                        <em><?= get_the_time('M d,Y') ?>&nbsp;by <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php echo get_the_author(); ?></a></em>
                    </div>
                    <!-- col end here -->
                </div>
                <!-- row end here -->
                <hr>
                <?php endwhile; else: ?>
                <strong><?php _e('No posts by this author.'); ?></strong>
                <?php endif; ?>      
                
            </div>
            <?php get_sidebar(); ?>
        </div>
    </div>
</div>
<?php get_footer(); ?>