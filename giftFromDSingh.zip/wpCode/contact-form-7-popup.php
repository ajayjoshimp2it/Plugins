/**
 * Display Contact Form 7 responses in a popup.
 */

function ContactForm7_popup() {

	$return = <<<EOT
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
	<script>	
		jQuery(".wpcf7-form a,.wpcf7-form button").click(function(event) {
			jQuery( document ).one( "ajaxComplete", function(event, xhr, settings) {
				var data = xhr.responseText;
				var jsonResponse = JSON.parse(data);
				 //console.log(jsonResponse);
				
				if(! jsonResponse.hasOwnProperty('into') || jQuery('.wpcf7' + jsonResponse.into).length === 0) return;	
				var response = '<div class="cf7_popup">';
				if(jsonResponse['status']=="mail_sent")
					 response+= '<div class="message"><span style="color:green;font-size:18px;font-weight:500;">' + jsonResponse.message + '</span></div>';
				else
				    response+= '<div class="message"><span style="color:red;font-size:18px;font-weight:500;">' + jsonResponse.message + '</span></div>';
				
					response+='<div>';
				jQuery.fancybox.open(
						response,
						{					
						smallBtn : true,
						toolbar : false
					    }
				);
			});
		});
	</script>
	<style>
		.cf7_popup.fancybox-content{
			background: var(--main-theme-color-contrast);
			
		}
		div.wpcf7-response-output, div.wpcf7-validation-errors { display:none !important; }
		/*span.wpcf7-not-valid-tip { display: block; }*/
		input[aria-invalid="true"], select[aria-invalid="true"] { border-color: #ff2c00; // background-color: rgba(153,0,0,0.3); }
	</style>

EOT;
	echo $return;
}
add_action( 'wp_footer', 'ContactForm7_popup', 20 );