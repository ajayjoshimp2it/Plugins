<?php 
register_nav_menus( array(
	'header_menu' => 'Header Menu'
) );
add_theme_support( 'custom-header' );
add_theme_support( 'post-thumbnails' );
/*
if ( function_exists('register_sidebar') )
  register_sidebar(array(
    'name' => 'Heading',
    'id' => 'sidebar-1',
    'before_widget' => '<div class="links">',
    'after_widget' => '</div>',
    'before_title' => '<h5>',
    'after_title' => '</h5>',
  )
);
*/

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	/*add_theme_support(
		'post-formats', array(
            'chat',
			'aside',
			'image',
			'video',
			'quote',
			'link',
			'gallery',
			'audio',
            'status'
		)
	);
if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Membership") ) :
endif;
*/
/*
hide update notifications

function remove_core_updates(){
global $wp_version;return(object) array('last_checked'=> time(),'version_checked'=> $wp_version,);
}
add_filter('pre_site_transient_update_core','remove_core_updates');
add_filter('pre_site_transient_update_plugins','remove_core_updates');
add_filter('pre_site_transient_update_themes','remove_core_updates');
*/
?>

<?php
/*$args = array( 'category' => '12','posts_per_page' => 1);
$lastposts = get_posts( $args );
foreach($lastposts as $post) : setup_postdata($post);
the_title();
the_post_thumbnail('medium', array('class'=> 'img-responsive ds-img')); 
echo get_the_time('M d,Y');
echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; 
echo substr( strip_tags( get_the_excerpt() ),0,140);
echo get_the_permalink(); 
preg_match('/<a href="(.+?)">/', get_the_content(), $match);
echo $match[1]; 
endforeach;*/
?>
<?php
/*$args = array('post_type' => 'project','posts_per_page' => 1);
$lastposts = get_posts( $args );
foreach($lastposts as $post) : setup_postdata($post);
the_excerpt();  the_post_thumbnail(array(445,445), array('class'=> 'img-responsive'));
endforeach;*/
?>
<?php
/*$defaults = array(
    'theme_location'  => 'CopyRight Menu',
    'menu'            => 'Menu 3',
    'container'       => '',
    'container_class' => '',
    'container_id'    => '',
    'menu_class'      => '',
    'menu_id'         => '',
    'echo'            => true,
    'fallback_cb'     => 'wp_page_menu',
    'before'          => '',
    'after'           => '',
    'link_before'     => '',
    'link_after'      => '',
    'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
    'depth'           => 0,
    'walker'          => ''
);
wp_nav_menu( $defaults );*/
?>
<?php
/*$items=wp_get_nav_menu_items('Main_Menu');
$arr1=array();
$arr2=array();    
foreach ($items as $val)
{
  if($val->menu_item_parent==0)
  {
    $arr1[]=$val;
  }
  else
  {
    $arr2[$val->menu_item_parent][]=$val;
  }
}
foreach($arr1 as $val)
{
  if (array_key_exists($val->ID,$arr2))
  {
    echo '<li class="dropdown"><a href="'.$val->url.'" data-toggle="dropdown" data-submenu>'.$val->title.'<i class="fa fa-chevron-down"></i></a><ul class="dropdown-menu">';
    foreach($arr2[$val->ID] as $val2)
      {
          echo '<li><a href="'.$val2->url.'">'.$val2->title.'</a></li>';
      }
    echo '</ul></li>';
  }
  else
  {
    echo '<li class=".'active_menu( $val )'."><a href="'.$val->url.'">'.$val->title.'</a></li>';
  }
}*/
/* End Menu Code */
?>
<?php
$items=wp_get_nav_menu_items('Main Menu');
$arr1=array();
$arr2=array();
foreach ($items as $val)
{
  if($val->menu_item_parent==0)
  {
    $arr1[]=$val;
  }
  else
  {
    $arr2[$val->menu_item_parent][]=$val;
  }
}
foreach($arr1 as $val){
  if (array_key_exists($val->ID,$arr2)){	?>
	<li class="dropdown">
         <a href="javascript:;" class="dropdown-toggle nav-link" data-toggle="dropdown"><?= $val->title; ?></a>
         <ul class="dropdown-menu">
<?php	foreach($arr2[$val->ID] as $val2){ ?>
<?php if (array_key_exists($val2->ID,$arr2)){ ?>
					<li class="dropdown">
           <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"><?= $val2->title; ?></a>
           <ul class="dropdown-menu">
					<?php	foreach($arr2[$val2->ID] as $val3) { ?>
						 <li><a href="<?= $val3->url; ?>" target="<?= $val3->target; ?>" title="<?= $val3->title; ?>"><?= $val3->title; ?></a></li>
<?php } ?>
						</ul>
					 </li>
<?php }else{ ?>
		<li><a
					href="<?= $val2->url; ?>"
					target="<?= $val2->target; ?>"
					title="<?= $val2->title; ?>" ><?= $val2->title; ?></a></li>
<?php	} } ?>
		</ul>
	 </li>
<?php }else{ ?>
<li><a class="nav-link" href="<?= $val->url; ?>" title="<?= $val->title; ?>" target="<?= $val->target; ?>" ><?= $val->title; ?></a></li>
<?php } } ?>

<?php /* Main Menu Items */
									$locations = get_nav_menu_locations();
									$menu_id = $locations[ 'menu-1' ] ;
									print_r(wp_get_nav_menu_object($menu_id));
											$items = wp_get_nav_menu_items($menu_id);
											if($items){
											foreach ($items as $val){	?>
									
									<li class="<?= active_menu( $val ) ?>"><a class="nav-link" href="<?= $val->url; ?>" title="<?= $val->title; ?>" target="<?= $val->target; ?>"><?= $val->title; ?></a></li>
									
									<?php	}}else{ ?>
									
									<li class="active"><a class="nav-link" href="#" title="Sample 1" target="">Sample Page 1</a></li>
									<li><a class="nav-link" href="#" title="Sample 2" target="">Sample Page 2</a></li>
									
									<?php	}	/* Main Menu Items end*/?>