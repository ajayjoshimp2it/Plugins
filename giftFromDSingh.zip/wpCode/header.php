<link rel="shortcut icon" href="<?= get_stylesheet_directory_uri(); ?>/favicon.ico" /> 
<a href="<?= get_site_url(); ?>/"><img src="<?= get_header_image(); ?>" class="img-responsive logo"></a>
src="<?= get_template_directory_uri(); ?>/