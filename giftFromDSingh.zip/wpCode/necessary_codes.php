<?php
// customizer section
add_action( 'customize_register', 'genesischild_register_theme_customizer' );
/*
 * Register Our Customizer Stuff Here
 */
function genesischild_register_theme_customizer( $wp_customize ) {
    // Create custom panel.
    $wp_customize->add_panel( 'text_blocks', array(
        'priority'       => 500,
        'theme_supports' => '',
        'title'          => __( 'Footer Section', 'genesischild' ),
        'description'    => __( 'Set editable text for certain content.', 'genesischild' ),
    ) );
    // Add Footer Text
    // Add section for headquater.
    $wp_customize->add_section( 'custom_footer_headquater' , array(
        'title'    => __('Headquater Text','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_headquater_block', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_footer_headquater',
            array(
                'label'    => __( 'Headquater Text', 'genesischild' ),
                'section'  => 'custom_footer_headquater',
                'settings' => 'footer_headquater_block',
                'type'     => 'textarea'
            )
        )
    );
    
    //add section for reseach
    $wp_customize->add_section( 'custom_footer_research' , array(
        'title'    => __('Research Text','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_research_block', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_footer_research',
            array(
                'label'    => __( 'Research Text', 'genesischild' ),
                'section'  => 'custom_footer_research',
                'settings' => 'footer_research_block',
                'type'     => 'textarea'
            )
        )
    );
    
    //add section for question
    $wp_customize->add_section( 'custom_footer_question' , array(
        'title'    => __('Question Email','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_question_block', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_footer_question',
            array(
                'label'    => __( 'Question Email', 'genesischild' ),
                'section'  => 'custom_footer_question',
                'settings' => 'footer_question_block',
                'type'     => 'text'
            )
        )
    );
    
    //add section for question
    $wp_customize->add_section( 'custom_issue_question' , array(
        'title'    => __('Issue Email','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_issue_block', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_issue_question',
            array(
                'label'    => __( 'Issue Email', 'genesischild' ),
                'section'  => 'custom_issue_question',
                'settings' => 'footer_issue_block',
                'type'     => 'text'
            )
        )
    );
    
    //add section for question
    $wp_customize->add_section( 'custom_headquater_no' , array(
        'title'    => __('Headquater Mobile number','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_headquater_no', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_headquater_no',
            array(
                'label'    => __( 'Headquater Number', 'genesischild' ),
                'section'  => 'custom_headquater_no',
                'settings' => 'footer_headquater_no',
                'type'     => 'text'
            )
        )
    );

    //add section for question
    $wp_customize->add_section( 'custom_research_no' , array(
        'title'    => __('Research Mobile number','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_research_no', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_research_no',
            array(
                'label'    => __( 'Research Mobile Number', 'genesischild' ),
                'section'  => 'custom_research_no',
                'settings' => 'footer_research_no',
                'type'     => 'text'
            )
        )
    );

    //add section for question
    $wp_customize->add_section( 'custom_copyright_text' , array(
        'title'    => __('Copyright text','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'footer_copyright', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_copyright_text',
            array(
                'label'    => __( 'Copyright text', 'genesischild' ),
                'section'  => 'custom_copyright_text',
                'settings' => 'footer_copyright',
                'type'     => 'textarea'
            )
        )
    );

    //add section for question
    $wp_customize->add_section( 'custom_facebook_text' , array(
        'title'    => __('Facebook link','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'social_facebook', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_facebook_text',
            array(
                'label'    => __( 'Facebook Link', 'genesischild' ),
                'section'  => 'custom_facebook_text',
                'settings' => 'social_facebook',
                'type'     => 'text'
            )
        )
    );

    //add section for question
    $wp_customize->add_section( 'custom_linked_text' , array(
        'title'    => __('Linked In link','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'social_linked', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_linked_text',
            array(
                'label'    => __( 'Linked In Link', 'genesischild' ),
                'section'  => 'custom_linked_text',
                'settings' => 'social_linked',
                'type'     => 'text'
            )
        )
    );
//add section for question
    $wp_customize->add_section( 'custom_twitter_text' , array(
        'title'    => __('Twitter link','genesischild'),
        'panel'    => 'text_blocks',
        'priority' => 10
    ) );
    // Add setting
    $wp_customize->add_setting( 'social_twitter', array(
         'default'           => __( 'default text', 'genesischild' ),
         'sanitize_callback' => 'test_sanitize_text'
    ) );
    // Add control
    $wp_customize->add_control( new WP_Customize_Control(
        $wp_customize,
        'custom_twitter_text',
            array(
                'label'    => __( 'Twitter Link', 'genesischild' ),
                'section'  => 'custom_twitter_text',
                'settings' => 'social_twitter',
                'type'     => 'text'
            )
        )
    );



    // Sanitize text
    /*function sanitize_text( $text ) {
        return sanitize_text_field( $text );
    }*/
     function test_sanitize_text( $input ) {
        $allowed_html = array(
            'br' => array(),
        );

        return wp_kses( $input, $allowed_html );
    }
}



<?php 
$id=47; 
$post = get_post($id); 
$content = apply_filters('the_content', $post->post_content); 
echo $content;  
?>

<?php 
function get_wp_page_link($page_slug) {
    $page = get_page_by_path($page_slug);
    if ($page) {
        return get_permalink($page->ID);
    } else {
        return '#';
    }
}


function get_wp_page_id($page_slug) {
    $page_id = get_page_by_path($page_slug);
    if ($page_id) {
        return $page->ID;
    } else {
        return '#';
    }
}

?>


<script type="text/javascript">
jQuery(document).bind("contextmenu",function(e) {
e.preventDefault();
});
document.onkeydown = function(e) {
  if(event.keyCode == 123) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
     return false;
  }
}	
</script>


//Get Woocommerce categories
<?php
	$args = array(
			'taxonomy' => "product_cat",
			'parent' => 0, 
			'exclude' => 16
	);
	$product_categories = get_terms($args);
	foreach($product_categories as $pro_cat){ ?>
		<li class="col-md-3 col-sm-3">
	<a href="<?= get_category_link($pro_cat->term_id); ?>" title="<?= $pro_cat->name; ?>">
		<img src="<?= wp_get_attachment_url(get_woocommerce_term_meta( $pro_cat->term_id, 'thumbnail_id', true )); ?>" class="img-responsive" alt="<?= $pro_cat->name; ?>">
		<h3><?= $pro_cat->name; ?></h3>
		<p><?= $pro_cat->description; ?></p>
	</a>
</li>
<?php	}	?>

///  Elementor Set top margin
<script>
var currentLocation = window.location;
var thisPageURI =  new URL(	currentLocation );

if(thisPageURI.searchParams.get("elementor-preview") && thisPageURI.searchParams.get("ver") ){
	jQuery('#element-page').css('padding-top','100px');
}
</script>




// Get child pages By parent page ID
<?php
$parent = new WP_Query(array(
    'post_parent'       => 27,
		'post_type'         => 'page',
    'order'             => 'ASC',
    'orderby'           => 'menu_order',
    'posts_per_page'    => -1
));
if ($parent->have_posts()) : ?>
    <?php while ($parent->have_posts()) : $parent->the_post(); ?>
			 <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><i class="fa fa-map-o"></i> <?php the_title(); ?></a></li> 
    <?php endwhile; ?>
<?php unset($parent); endif; wp_reset_postdata(); ?>


Slider WP widget
<?php
ob_start(); 
dynamic_sidebar("woocommerce-img");																									 
$cont = ob_get_contents();
preg_match_all('/<img[^>]+>/i',$cont, $contArray); 
preg_match_all('#\<a .*?\>.*?\<\/a\>#i',$cont, $contArray); 
ob_end_clean();
?>
														Stars
 
<?php global $post, $product;
		$lenOfCat = count($product->category_ids);
    echo get_the_category_by_ID($product->category_ids[$lenOfCat-1]); 
		$rating_count = $product->get_rating_count();
		$average = $product->get_average_rating();
		echo wc_get_rating_html( $average, $rating_count );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
?>

														Child Theme
/*
 Theme Name:   Evie Blender Child Theme
 Description:  A Twenty Thirteen child theme 
 Author:       DSingh
 Template:     EvieBlender
 Version:      1.0.0
*/
@import url("../EvieBlender/style.css");
//For style.css
<?php
/*For Functions.php*/
add_action( 'wp_enqueue_scripts', 'enqueue_child_theme_styles', PHP_INT_MAX);
function enqueue_child_theme_styles() {
  wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
}
?>

														Manage Wordpress Roles

<?php


function populate_roles_160() {
    // Add roles
 
    // Dummy gettext calls to get strings in the catalog.
    /* translators: user role */
    _x('Administrator', 'User role');
    /* translators: user role */
    _x('Editor', 'User role');
    /* translators: user role */
    _x('Author', 'User role');
    /* translators: user role */
    _x('Contributor', 'User role');
    /* translators: user role */
    _x('Subscriber', 'User role');
 
    add_role('administrator', 'Administrator');
    add_role('editor', 'Editor');
    add_role('author', 'Author');
    add_role('contributor', 'Contributor');
    add_role('subscriber', 'Subscriber');
 
    // Add caps for Administrator role
    $role = get_role('administrator');
    $role->add_cap('switch_themes');
    $role->add_cap('edit_themes');
    $role->add_cap('activate_plugins');
    $role->add_cap('edit_plugins');
    $role->add_cap('edit_users');
    $role->add_cap('edit_files');
    $role->add_cap('manage_options');
    $role->add_cap('moderate_comments');
    $role->add_cap('manage_categories');
    $role->add_cap('manage_links');
    $role->add_cap('upload_files');
    $role->add_cap('import');
    $role->add_cap('unfiltered_html');
    $role->add_cap('edit_posts');
    $role->add_cap('edit_others_posts');
    $role->add_cap('edit_published_posts');
    $role->add_cap('publish_posts');
    $role->add_cap('edit_pages');
    $role->add_cap('wpseo_manage_options');
    $role->add_cap('read');
    $role->add_cap('level_10');
    $role->add_cap('level_9');
    $role->add_cap('level_8');
    $role->add_cap('level_7');
    $role->add_cap('level_6');
    $role->add_cap('level_5');
    $role->add_cap('level_4');
    $role->add_cap('level_3');
    $role->add_cap('level_2');
    $role->add_cap('level_1');
    $role->add_cap('level_0');
 
    // Add caps for Editor role
    $role = get_role('editor');
    $role->add_cap('moderate_comments');
    $role->add_cap('manage_categories');
    $role->add_cap('manage_links');
    $role->add_cap('upload_files');
    $role->add_cap('unfiltered_html');
    $role->add_cap('edit_posts');
    $role->add_cap('edit_others_posts');
    $role->add_cap('edit_published_posts');
    $role->add_cap('publish_posts');
    $role->add_cap('edit_pages');
    $role->add_cap('read');
    $role->add_cap('level_7');
    $role->add_cap('level_6');
    $role->add_cap('level_5');
    $role->add_cap('level_4');
    $role->add_cap('level_3');
    $role->add_cap('level_2');
    $role->add_cap('level_1');
    $role->add_cap('level_0');
 
    // Add caps for Author role
    $role = get_role('author');
    $role->add_cap('upload_files');
    $role->add_cap('edit_posts');
    $role->add_cap('edit_published_posts');
    $role->add_cap('publish_posts');
    $role->add_cap('read');
    $role->add_cap('level_2');
    $role->add_cap('level_1');
    $role->add_cap('level_0');
 
    // Add caps for Contributor role
    $role = get_role('contributor');
    $role->add_cap('edit_posts');
    $role->add_cap('read');
    $role->add_cap('level_1');
    $role->add_cap('level_0');
 
    // Add caps for Subscriber role
    $role = get_role('subscriber');
    $role->add_cap('read');
    $role->add_cap('level_0');
}


add_action('init', function()
{
    remove_role('plugins_manager');
});
add_action('init', function()
{
    $role = get_role('contributor');
    $role->add_cap('install_plugins');
});
add_action('init', function()
{
    $role = get_role('contributor');
    $role->remove_cap('install_plugins');
});





function new_role() {  
  add_role(
    'role_name',
    "Role Name",
    array(
      'read'         => true,
      'delete_posts' => false
    )
  );
}
add_action('admin_init', 'new_role');   

function uiwc_change_role( $order_id ) {
  // get all the order data
  $order = new WC_Order($order_id);
  
  //get the user email from the order
  $user = $order->get_user();
    
  // if the this is a registered user and this user is not an admin
  if( false != $user && !user_can($user, 'administrator') ){
  
    // our new role name
    $role = 'role_name';
  
    //set the new role to our customer
    $user->set_role($role);  
   
  }  
}
 
//add this newly created function to the thank you page
add_action( 'woocommerce_thankyou', 'uiwc_change_role', 100, 1 );
?>



																			Request for Price
<?php
add_filter('woocommerce_empty_price_html', 'essyrug_poa_and_enquiry_cf7_woocommerce');
 
function essyrug_poa_and_enquiry_cf7_woocommerce() {
 $html='<button type="submit" id="trigger_cf" class="single_add_to_cart_button button alt">Request Price</button>';
$html.='<div id="product_inq" style="display:none">';
$html.=do_shortcode('[contact-form-7 id="33622" title="POA Handmade"]');
$html.='</div>';
    return $html;
}

add_action( 'woocommerce_single_product_summary', 'bbloomer_on_click_show_cf7_and_populate', 40 );
 
function bbloomer_on_click_show_cf7_and_populate() {
   
  ?>
    <script type="text/javascript">
        jQuery('#trigger_cf').on('click', function(){
        if ( jQuery(this).text() == 'Request Price' ) {
                    jQuery('#product_inq').css("display","block");
                    jQuery('input[name="text-681"]').val('<?php the_title(); ?>');
            jQuery("#trigger_cf").html('Close'); 
        } else {
            jQuery('#product_inq').hide();
            jQuery("#trigger_cf").html('Request Price'); 
        }
        });
    </script>
<?php } ?>
                                        Dynamic cart update
<?php
add_filter( 'woocommerce_add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment' );

function woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;

	ob_start();

?>
	<a class="cart-customlocation" href="<?php echo esc_url(wc_get_cart_url()); ?>" title="<?php _e('View your shopping cart', 'woothemes'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a>

<?php
	$fragments['a.cart-customlocation'] = ob_get_clean();
	return $fragments;
}
?>
                                        //Mail Function
<?php 
include '../wp-load.php';

$to = 'example@example.com';
$subject = 'The subject';
$body = 'The email body content';
$headers = array('Content-Type: text/html; charset=UTF-8');

wp_mail($to, $subject, $body, $headers);
?>
                                            //To add post
<?php	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support(
		'post-formats', array(
            'chat',
			'aside',
			'image',
			'video',
			'quote',
			'link',
			'gallery',
			'audio',
            'status'
		)
	); ?>
                                            //To get category
<?php $args = array(
    'show_option_all'    => ,
    'orderby'            => 'name',
    'order'              => 'ASC',
    'style'              => 'list',
    'show_count'         => 0,
    'hide_empty'         => 1,
    'use_desc_for_title' => 1,
    'child_of'           => 0,
    'feed'               => ,
    'feed_type'          => ,
    'feed_image'         => ,
    'exclude'            => ,
    'exclude_tree'       => ,
    'include'            => ,
    'hierarchical'       => true,
    'title_li'           => __( 'Categories' ),
    'show_option_none'   => __('No categories'),
    'number'             => NULL,
    'echo'               => 1,
    'depth'              => 0,
    'current_category'   => 0,
    'pad_counts'         => 0,
    'taxonomy'           => 'category',
    'walker'             => 'Walker_Category' ); ?>
set_post_thumbnail_size( 200, 200, true ); // Sets the Post Main Thumbnails 
add_image_size( 'dsingh-cstm', 55, 55, true );//Sets Recent Posts Thumbnails 
<?php
$lastposts = query_posts(array('post_type' => 'side_posts','side-post-cat' => 'Work with us','posts_per_page' => 10, 'paged' => $paged));
the_permalink(); – Displays the URL of the product.
the_content(); – Displays the full description of the product.
the_excerpt(); – Displays a brief description of the product.
the_ID(); – Displays the product’s ID.
the_title(); – Displays the name of the product.
the_post_thumbnail(); – Displays the product image.
echo gmdate('Y-m-d H:i:s', strtotime($date));
?>


                            //Fetch All Authors
<?php 
$authors = get_users('role=author&orderby=display_name&order=ASC');
echo "<pre>";
print_r($authors); echo "</pre>";
foreach ($authors as $author) {
    if (count_user_posts($author->ID) > 0) {
       echo '<li id="' . $author->ID . '">' . $author->user_email . '</li>';
    }
}
?>

                        
                                //hook to redirect single page content on another page
<?php

//single page design layout 
function get_custom_cat_template($single_template) {
   global $post;
   $parent     = '21'; //Change to your category ID
    $categories = get_categories( 'child_of=' . $parent );
	echo 'tseting';
    if ( has_category( 'category_name' ) || @$categories[array_keys($categories)[0]]->parent == 21 ) {
		echo 'tset';
        $single_template = @dirname( __FILE__ ) . '/single-datahub.php';
    }
   return $single_template;
} 
add_filter( "single_template", "get_custom_cat_template" ) ;
?>


                                //To fetch all sub categories
<?php
$args = array(			'type'                     => 'post',			'child_of'                 => 21,			'orderby'                  => 'name',			'order'                    => 'ASC',			'hide_empty'               => FALSE,			'hierarchical'             => 1,			'taxonomy'                 => 'category',		);                                For adding more formats to post
?>
<?php
function add_post_formats() {
    add_theme_support( 'post-formats', array( 'gallery', 'quote', 'video', 'aside', 'image', 'link' ) );
}
 
add_action( 'after_setup_theme', 'add_post_formats', 20 );
?>


                                    For Adding Custom Post 
<?php
function custom_post() {
    register_post_type( 'custom-post',
        array(
            'labels' => array(
                'name' => 'Custom Posts',
                'singular_name' => 'Custom Posts',
                'add_new' => 'Add Custom Posts',
                'add_new_item' => 'Add Custom Posts',
                'edit' => 'Edit',
                'edit_item' => 'Edit Custom Posts',
                'new_item' => 'New Custom Posts',
                'view' => 'View',
                'view_item' => 'View Custom Posts',
                'all_items' =>'All Custom Posts',
                'search_items' => 'Search Custom Posts',
                'not_found' => 'No Custom Posts found',
                'not_found_in_trash' => 'No Custom Posts found in Trash',
                'parent' => 'Parent Custom Posts'
            ), 
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array(''),
            'menu_icon' => '',
            'has_archive' => true
        )
    ); 
}  
function custom_post_taxonomies() {
    register_taxonomy(
        'custom-post-cat',
        'custom-post',
        array(
            'labels' => array(
                'name' => 'Custom Posts Category',
                'add_new_item' => 'Add New Category',
                'new_item_name' => "New Offer Type Genre"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'hierarchical' => true
            )
    );
}
add_action( 'init', 'custom_post' );
add_action( 'init', 'custom_post_taxonomies', 0 );
?>
<?php
$args = array('post_type' => 'custom-post','custom-post-cat' => 'test','posts_per_page' => 5);
$lastposts = get_posts( $args );
foreach($lastposts as $post) : setup_postdata($post); ?>
<p><a href="<?= get_the_permalink(); ?>">link</a></p>
<p><?php the_post_thumbnail(array(300,300), array('class'=> 'img-responsive')); ?></p>
<h1><?php the_title(); ?></h1>
<p><?= substr( strip_tags( get_the_excerpt() ),0,250); ?></p>
<p><?= get_the_time('M d,Y'); ?>&emsp;<strong><?= get_comments_number(); ?></strong></p>
<a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php echo get_the_author(); ?></a>
<?php endforeach; ?>


                                        For making popular post & call
<?php setPostViews(get_the_ID()); //In single.php ?>
<?php
function setPostViews($postID) {
    $countKey = 'post_views_count';
    $count = get_post_meta($postID, $countKey, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $countKey);
        add_post_meta($postID, $countKey, '0');
    }else{
        $count++;
        update_post_meta($postID, $countKey, $count);
    }
}
//In functions.php
?>
<?php
//Put where you want to call
query_posts('meta_key=post_views_count&posts_per_page=5&orderby=meta_value_num&order=DESC');
if (have_posts()) : while (have_posts()) : the_post();
?>
  <a href="<?php the_permalink() ?>"><?php the_post_thumbnail(array(97,67), array('class'=> 'img-responsive imagee')); ?></a> 
  <a href="<?php the_permalink() ?>"><p><?php the_title(); ?></p></a>
  <a href="<?php the_permalink() ?>"><span><?= get_comments_number(); ?></span></a>
<?php endwhile; endif; wp_reset_query();?>

                                        For Post pagination
<?php
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args = array('post_type' => 'post', 'posts_per_page' => 4, 'paged' => $paged );
$post_type_data = new WP_Query($args);

set_query_var('page',$paged);
while ($post_type_data->have_posts()): $post_type_data->the_post(); global $more; $more = 0; ?>

            <?php if (has_post_thumbnail()): ?>
            <?php the_post_thumbnail('full', array('class'=> 'img-responsive')); ?>
            <?php endif; ?>
       <?php echo the_permalink(); ?>
                <?php echo the_title(); ?>
       
<?php echo get_the_date('j'); ?> <?php echo the_time('M'); ?>, <?php echo the_time('Y'); ?>
       
       <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><?php echo get_the_author(); ?></a>
        <?= substr( strip_tags( get_the_excerpt() ),0,140); ?>
    <?php endwhile; ?>
    <div class="nav-previous">
        <?php previous_posts_link('&laquo; Newer posts');?>
    </div>
    <div class="nav-next">
        <?php next_posts_link( 'Older posts &raquo;', $post_type_data->max_num_pages ); ?>
    </div> 


                                    Woo Related Products
<?php
global $product;

    $cats          = wc_get_product_terms( $product->id, 'product_cat', array( 'fields' => 'slugs' ) );
    $brands        = wc_get_product_terms( $product->id, 'pa_brand', array( 'fields' => 'slugs' ) );
    $collections   = wc_get_product_terms( $product->id, 'pa_collection', array( 'fields' => 'slugs' ) );    

    unset( $args['post__in'] );
    $args['tax_query'] = array( 
        'relation' => 'OR',
        array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $cats,
        ),
        array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'pa_brand',
                'field'    => 'slug',
                'terms'    => $brands,
            ),
            array(
                'taxonomy' => 'pa_collection',
                'field'    => 'slug',
                'terms'    => $collections,
            )
        )
    );

?>

                                    For woocommerce best selling product
<?php
$args = array(
    'post_type'     => 'product',
    'post_status'   => 'publish',
    'posts_per_page'=> 10,
    'orderby'       => 'total_sales',
    'order'         => 'DESC',
    'meta_query'    => array(
        'relation'  => 'OR',
        array(
            'key'       => '_featured',
            'value'     => 'yes',
            'compare'   => '='
        ),
        array(
            'key'       => 'total_sales',
            'value'     => '10',
            'compare'   => '>='
        )
    )
);
$query = new WP_Query( $args );
?>

                                    For Featured Products:
<?php                          
$args = array(
'post_type'           => 'product',
'post_status'         => 'publish',
'ignore_sticky_posts' => 1,
'posts_per_page'      => 8,
'orderby'             => 'date',
'order'               => 'desc',
'tax_query' => array(
                array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                ),
            )
);                            
$loop = new WP_Query($args);                            
while ( $loop->have_posts() ) : $loop->the_post();?>
<div class="crsl-item">
   
    <div class="watch_bg">
        <a href="<?php the_permalink(); ?>">
            <?php if (has_post_thumbnail($loop->post->ID)) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog', array('class' => 'img-responsive')); else echo '<img src="' . woocommerce_placeholder_img_src() . '" alt="Placeholder" width="300px" height="300px" />'; ?></a>
    </div>

    <a href="<?php echo get_permalink($loop->post->ID) ?>">
        <h4>
            <?php the_title(); ?>
        </h4>
    </a>
    <div class="album">
        <?php woocommerce_template_loop_add_to_cart($loop->post, $product); ?>
        <?= do_shortcode('[ti_wishlists_addtowishlist loop="yes"]') ?>
    </div>

    <h5>
        <?php echo $product->get_price_html(); ?>
    </h5>
    <!-- album end here -->
</div>
<!-- crsl-item end here -->
<?php endwhile;
wp_reset_query(); 
?>


                            For Custom Product Call:

<?php

 $arr = ('meta_query'     => array(// For Sale
                    'relation' => 'OR',
                    array( // Simple products type
                        'key'           => '_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    ),
                    array( // Variable products type
                        'key'           => '_min_variation_sale_price',
                        'value'         => 0,
                        'compare'       => '>',
                        'type'          => 'numeric'
                    )
                )
);
$args = array('post_type' => 'product', 'posts_per_page' => 8,'meta_key' => 'total_sales',
    'orderby' => 'meta_value_num');
$loop = new WP_Query($args);
while ($loop->have_posts()) : $loop->the_post(); ?>


    <div class="crsl-item">
            <div class="watch_bg">
                <a href="<?php the_permalink(); ?>">
                    <?php if (has_post_thumbnail($loop->post->ID)) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog', array('class' => 'img-responsive')); else echo '<img src="' . woocommerce_placeholder_img_src() . '" alt="Placeholder" width="300px" height="300px" />'; ?>
                </a>
            </div>
        <a href="<?php echo get_permalink($loop->post->ID) ?>"><h4><?php the_title(); ?></h4></a>
<div class="album">
<?php woocommerce_template_loop_add_to_cart($loop->post, $product); ?>
<?= do_shortcode('[ti_wishlists_addtowishlist loop="yes"]') ?>
</div>
            <h5><?php echo $product->get_price_html(); ?></h5>
    </div>
<?php endwhile;
wp_reset_query(); 
?>



                                For Custom Menu Code:
<?php
$items=wp_get_nav_menu_items('Secondary_Menu');
/* Menu Code */
foreach ($items as $val)
{
  if($val->menu_item_parent==0)
  {
    $arr1[]=$val;
  }
  else
  {
    $arr2[$val->menu_item_parent][]=$val;
  }
}
foreach($arr1 as $val)
{
  if (array_key_exists($val->ID,$arr2))
  {
    echo '<li class="dropdown"><a href="'.$val->url.'" data-toggle="dropdown" data-submenu>'.$val->title.'<b class="caret"></b></a><ul class="dropdown-menu">';
    foreach($arr2[$val->ID] as $val2)
      {
        if(array_key_exists($val2->ID,$arr2))
        {
          echo '<li class="dropdown-submenu"><a href="'.$val2->url.'">'.$val2->title.'<b class="caret"></b></a><ul class="dropdown-menu">';
          foreach($arr2[$val2->ID] as $val3)
          {
            echo '<li><a href="'.$val3->url.'">'.$val3->title.'</a></li>';
          }
          echo '</ul></li>';
        }
        else
        {
          echo '<li><a href="'.$val2->url.'">'.$val2->title.'</a></li>';
        }
      }
    echo '</ul></li>';
  }
  else
  {
    echo '<li><a href="'.$val->url.'">'.$val->title.'</a></li>';
  }
}
/* End Menu Code */
?>  

                             
                                                          
                        For Active Menu Class:
<?php
function active_menu( $menu_item ) 
{
    $actual_link = ( isset( $_SERVER['HTTPS'] ) ? "https" : "http" ) . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    if ( $actual_link == $menu_item->url ) {
        return 'active';
    }
    return '';
} ?>

                                    Some other codes:
<?php  /* Put these in functions.php */
add_theme_support('woocommerce');
add_theme_support( 'custom-header' );
add_theme_support( 'post-thumbnails' );
?>


                                    For Home Page if woocommerce
<?php global $woocommerce; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>> 

                                  For Pagination of Woo Product
<?php
    global $paged;
    $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
    $args = array( 'post_type' => 'product','paged' => $paged);
    $loop = new WP_Query( $args );
    while ( $loop->have_posts() ) : $loop->the_post(); global $product; 
?>
<?php endwhile; ?>
<?php wp_reset_query(); ?>                                                                    
<div class="nav pagination-bottom">
  <div class="row">
    <div class="col-sm-12">
      <center>
      <?php if (function_exists("pagination"))
      {
          pagination($loop->max_num_pages);
      }
      ?>
    </center>
    </div>
  </div>
</div>
<?php wp_reset_query(); ?>           

    