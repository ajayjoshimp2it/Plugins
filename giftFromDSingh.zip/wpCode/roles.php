<?php 
WP_Roles Object
(
    [roles] => Array
        (
            [administrator] => Array
                (
                    [name] => Owner
                    [capabilities] => Array
                        (
                            [switch_themes] => 1
                            [edit_themes] => 1
                            [activate_plugins] => 1
                            [edit_plugins] => 1
                            [edit_users] => 1
                            [edit_files] => 1
                            [manage_options] => 1
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [import] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_10] => 1
                            [level_9] => 1
                            [level_8] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [delete_users] => 1
                            [create_users] => 1
                            [unfiltered_upload] => 1
                            [edit_dashboard] => 1
                            [update_plugins] => 1
                            [delete_plugins] => 1
                            [install_plugins] => 1
                            [update_themes] => 1
                            [install_themes] => 1
                            [update_core] => 1
                            [list_users] => 1
                            [remove_users] => 1
                            [promote_users] => 1
                            [edit_theme_options] => 1
                            [delete_themes] => 1
                            [export] => 1
                            [wpseo_manage_options] => 1
                        )

                )

            [editor] => Array
                (
                    [name] => Editor
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                        )

                )

            [author] => Array
                (
                    [name] => Author
                    [capabilities] => Array
                        (
                            [upload_files] => 1
                            [edit_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [read] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [delete_posts] => 1
                            [delete_published_posts] => 1
                        )

                )

            [contributor] => Array
                (
                    [name] => Contributor
                    [capabilities] => Array
                        (
                            [edit_posts] => 1
                            [read] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [delete_posts] => 1
                        )

                )

            [subscriber] => Array
                (
                    [name] => Subscriber
                    [capabilities] => Array
                        (
                            [read] => 1
                            [level_0] => 1
                        )

                )

            [wpseo_manager] => Array
                (
                    [name] => SEO Manager
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                            [wpseo_edit_advanced_metadata] => 1
                            [wpseo_manage_options] => 1
                        )

                )

            [wpseo_editor] => Array
                (
                    [name] => SEO Editor
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                            [wpseo_edit_advanced_metadata] => 1
                        )

                )

        )

    [role_objects] => Array
        (
            [administrator] => WP_Role Object
                (
                    [name] => administrator
                    [capabilities] => Array
                        (
                            [switch_themes] => 1
                            [edit_themes] => 1
                            [activate_plugins] => 1
                            [edit_plugins] => 1
                            [edit_users] => 1
                            [edit_files] => 1
                            [manage_options] => 1
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [import] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_10] => 1
                            [level_9] => 1
                            [level_8] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [delete_users] => 1
                            [create_users] => 1
                            [unfiltered_upload] => 1
                            [edit_dashboard] => 1
                            [update_plugins] => 1
                            [delete_plugins] => 1
                            [install_plugins] => 1
                            [update_themes] => 1
                            [install_themes] => 1
                            [update_core] => 1
                            [list_users] => 1
                            [remove_users] => 1
                            [promote_users] => 1
                            [edit_theme_options] => 1
                            [delete_themes] => 1
                            [export] => 1
                            [wpseo_manage_options] => 1
                        )

                )

            [editor] => WP_Role Object
                (
                    [name] => editor
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                        )

                )

            [author] => WP_Role Object
                (
                    [name] => author
                    [capabilities] => Array
                        (
                            [upload_files] => 1
                            [edit_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [read] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [delete_posts] => 1
                            [delete_published_posts] => 1
                        )

                )

            [contributor] => WP_Role Object
                (
                    [name] => contributor
                    [capabilities] => Array
                        (
                            [edit_posts] => 1
                            [read] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [delete_posts] => 1
                        )

                )

            [subscriber] => WP_Role Object
                (
                    [name] => subscriber
                    [capabilities] => Array
                        (
                            [read] => 1
                            [level_0] => 1
                        )

                )

            [wpseo_manager] => WP_Role Object
                (
                    [name] => wpseo_manager
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                            [wpseo_edit_advanced_metadata] => 1
                            [wpseo_manage_options] => 1
                        )

                )

            [wpseo_editor] => WP_Role Object
                (
                    [name] => wpseo_editor
                    [capabilities] => Array
                        (
                            [moderate_comments] => 1
                            [manage_categories] => 1
                            [manage_links] => 1
                            [upload_files] => 1
                            [unfiltered_html] => 1
                            [edit_posts] => 1
                            [edit_others_posts] => 1
                            [edit_published_posts] => 1
                            [publish_posts] => 1
                            [edit_pages] => 1
                            [read] => 1
                            [level_7] => 1
                            [level_6] => 1
                            [level_5] => 1
                            [level_4] => 1
                            [level_3] => 1
                            [level_2] => 1
                            [level_1] => 1
                            [level_0] => 1
                            [edit_others_pages] => 1
                            [edit_published_pages] => 1
                            [publish_pages] => 1
                            [delete_pages] => 1
                            [delete_others_pages] => 1
                            [delete_published_pages] => 1
                            [delete_posts] => 1
                            [delete_others_posts] => 1
                            [delete_published_posts] => 1
                            [delete_private_posts] => 1
                            [edit_private_posts] => 1
                            [read_private_posts] => 1
                            [delete_private_pages] => 1
                            [edit_private_pages] => 1
                            [read_private_pages] => 1
                            [wpseo_bulk_edit] => 1
                            [wpseo_edit_advanced_metadata] => 1
                        )

                )

        )

    [role_names] => Array
        (
            [administrator] => Owner
            [editor] => Editor
            [author] => Author
            [contributor] => Contributor
            [subscriber] => Subscriber
            [wpseo_manager] => SEO Manager
            [wpseo_editor] => SEO Editor
        )

    [role_key] => wp8y_user_roles
    [use_db] => 1
    [site_id:protected] => 1
)
?>