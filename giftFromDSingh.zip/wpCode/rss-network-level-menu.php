<?php
/**
 * Dashboard widget for RSS Feed
 */

add_action('wp_dashboard_setup', 'RSS_Feed_dashboard_widgets');

function RSS_Feed_dashboard_widgets()  // register widget
{
	//global $wp_meta_boxes;

	wp_add_dashboard_widget('rss_feed_widget', 'RSS Feed', 'rss_feed_widget');
}

function rss_feed_widget() // callback body
{
	 
	    $feed_url = get_site_option( 'rss_feed_url')?:''; // get feed url

	    if (function_exists('fetch_feed') && $feed_url != '') {

		include_once(ABSPATH . WPINC . '/feed.php');
		
		$feed = fetch_feed($feed_url);//get feeds

		$max_feeds = (int)get_site_option( 'rss_feed_max')?:5;  // network site options

		$limit = $feed->get_item_quantity($max_feeds-1); // specify number of items -1 
		$items = $feed->get_items(0, $limit); // create an array of items	 
	  }
	$count = 0;
	if ($limit == 0)
		$html = '<div>The feed is either empty or unavailable.</div>';
	else
		foreach ($items as $item) {
			$count++;
			if ($count == 1)
				$html .= '<div><a href="' . $item->get_permalink() . '" target="_blank" title="' . $item->get_date('j F Y @ g:i a') . '"><b>' . $item->get_title() . '</b></a>
	</div><div><i>' . wp_trim_words($item->get_description(), 20) . '</i></div>';
			$html .= '<hr><div ><a href="' . $item->get_permalink() . '" target="_blank" title="' . $item->get_date('j F Y @ g:i a') . '"><b>' . $item->get_title() . '</b></a>
	</div><div><i>' . wp_trim_words($item->get_description(), 20) . '</i></div>';
		}
	echo $html;
}

/***
 * Single Site Admin Notes dashboard widgets
 */

add_action('wp_dashboard_setup', 'admin_notes_dashboard_widgets');

function admin_notes_dashboard_widgets()  // register widget
{
	//global $wp_meta_boxes;

	wp_add_dashboard_widget('admin_notes_widget', 'Admin Notes', 'admin_notes_widget');
}

function admin_notes_widget() // callback body
{
	 
	    $admin_notes= get_site_option( 'site_admin_note')?:''; // get admin Notes

		if($admin_notes==''	)
		{
			$html = '<div>The Admin Notes is either empty or unavailable.</div>';
		}    
		else
		{
			$html  ='<div><p>'.$admin_notes.'</p></div>';
		}
	
	echo $html;
}

/***
 * Single Site Admin Support links dashboard widgets
 */

add_action('wp_dashboard_setup', 'ao_support_dashboard_widgets');

function ao_support_dashboard_widgets()  // register widget
{
	//global $wp_meta_boxes;

	wp_add_dashboard_widget('ao_support_widget', 'AgentOptix Support', 'ao_support_widget');
}

function ao_support_widget() // callback body
{
	 
	//$admin_notes= get_site_option( 'site_admin_note')?:''; // get admin Notes

    $youtube_url = get_site_option( 'youtube_url')?:''; // Youtube url
	$fb_group = get_site_option( 'private_facebook_group')?:''; //facebook group url
	$screenshare = get_site_option( 'request_consultation_screenShare_meeting')?:''; //screen share url
	$help_email = get_site_option( 'help_email')?:''; //help email

	$html='';	
	if($youtube_url!='')
	{
		$html.='<div> <b>Youtube URL:</b> <a href="'.$youtube_url.'" traget="_blank" >'.$youtube_url.'</a></div>';
	}
	if($fb_group!='')
	{
		$html.='<hr><div> <b>Private Facebook Group URL: </b> <a href="'.$fb_group.'" target="_blank" >'.$fb_group.' </a></div>';
	}
	if($screenshare!='')
	{
		$html.='<hr><div> <b>Request Consultation ScreenShare Meeting: </b><a href="'.$screenshare.'" target="_blank" > '.$screenshare.'</a></div>';
	}
	if($help_email!='')
	{
		$html.='<hr><div> <b>Help Email: </b> <a href="mailto:'.$help_email.'" >'.$help_email.'</a></div>';
	}
	if($html=='')
	{
		$html.='<hr><div>The Admin Support is either empty or unavailable.</div>';
	}
	echo $html;

}

/*****  Multi Site Network Settings */
add_action("network_admin_menu", "agent_optix_network_theme_options");
function agent_optix_network_theme_options() {
 
	/* add_submenu_page(
		'themes.php', // Parent element
		'AO Settings', // Text in browser title bar
		'AO Settings', // Text to be displayed in the menu.
		'manage_options', // Capability
		'ao-settings', // Page slug, will be displayed in URL
		'misha_settings_page_1' // Callback function which displays the page
	); */
 
	add_menu_page(
		'AO Settings',
		'AO Settings',
		'manage_options',
		'ao-settings',
		'network_admin_settings',
 		'dashicons-admin-tools', // Icon
		15 // Position of the menu item in the menu.
	); 
}

function network_admin_settings() {
 
	$mu_setting_fields ='<div class="wrap"><h1>AGENTOPTIX SETTINGS</h1> <form method="post" action="edit.php?action=ms_network_settings">';	
	$mu_setting_fields.= wp_nonce_field('ao-network-validate').'<h2>GLOBAL </h2>
	<table class="form-table">
	<tr>
	<th scope="row">
	<label for="tracking_id">Tracking ID</label>
	</th>
	<td>
	<input name="tracking_id" class="regular-text" type="text" id="tracking_id" value="' . esc_attr( get_site_option( 'tracking_id') ) . '" />	<p class="description">Google Analytics Tracking ID can be added here.</p>
	</td>
	</tr>
	</table>';

	$mu_setting_fields.='<h2>SOCIAL </h2>
	<table class="form-table">
	<tr>
	<th scope="row">
	<label for="youtube_url">Youtube URL</label>
	</th>
	<td>
	<input name="youtube_url" class="regular-text" type="text" id="youtube_url" value="' . esc_attr( get_site_option( 'youtube_url') ) . '" />	<p class="description">Youtube URL can be added here.</p>
	</td>
	</tr>

	<tr>
	<th scope="row">
	<label for="private_facebook_group">Private Facebook Group URL</label>
	</th>
	<td>
	<input name="private_facebook_group" class="regular-text" type="text" id="private_facebook_group" value="' . esc_attr( get_site_option( 'private_facebook_group') ) . '" />	<p class="description">Private Facebook Group URL can be added here.</p>
	</td>
	</tr>	

	<tr>
	<th scope="row">
	<label for="request_consultation_screenShare_meeting">Request Consultation ScreenShare Meeting</label>
	</th>
	<td>
	<input name="request_consultation_screenShare_meeting" class="regular-text" type="text" id="request_consultation_screenShare_meeting" value="' . esc_attr( get_site_option( 'request_consultation_screenShare_meeting') ) . '" />	<p class="description">Request Consultation ScreenShare Meeting URL can be added here.</p>
	</td>
	</tr>
	</table>

	<h2>ADMIN </h2>
	<table class="form-table">
	<tr>
	<th scope="row">
	<label for="rss_feed_url">RSS Feed URL</label>
	</th>
	<td>
	<input name="rss_feed_url" class="regular-text" type="text" id="rss_feed_url" value="' . esc_attr( get_site_option( 'rss_feed_url') ) . '" />	<p class="description">RSS Feed URL can be added here.</p>
	</td>
	</tr>

	<tr>
	<th scope="row">
	<label for="rss_feed_max">Maximum RSS Feed</label>
	</th>
	<td>
	<input name="rss_feed_max" class="regular-text" type="number" id="rss_feed_max" value="' . esc_attr( get_site_option( 'rss_feed_max') ) . '" />	<p class="description">RSS Feed Max value can be added here.Default value 5 will be used.</p>
	</td>
	</tr>
	<tr>
	<th scope="row">
	<label for="site_admin_note">Site Admin Note</label>
	</th>
	<td>
	<textarea id="site_admin_note" class="regular-text" rows ="4" name="site_admin_note" >' . esc_attr( get_site_option( 'site_admin_note') ) . '</textarea>
	<p class="description">Website admin note can be added here.</p>	
	</td>
	</tr>
	</table>
	<h2>Others</h2>
	<table class="form-table">
	<tr>
	<th scope="row">
	<label for="bitmovin_api_key">Bitmovin API key</label>
	</th>
	<td>
	<input name="bitmovin_api_key" class="regular-text" type="text" id="bitmovin_api_key" value="' . esc_attr( get_site_option( 'bitmovin_api_key') ) . '" />	<p class="description">Bitmovin API key can be added here.</p>
	</td>
	</tr>
	<tr>
	<th scope="row">
	<label for="google_map_api_key">Google Map API key</label>
	</th>
	<td>
	<input name="google_map_api_key" class="regular-text" type="text" id="google_map_api_key" value="' . esc_attr( get_site_option( 'google_map_api_key') ) . '" />	<p class="description">Google Map API key can be added here.</p>
	</td>
	</tr>
	</table>	
	<h2>SUPPORT </h2>
	<table class="form-table">
	<tr>
	<th scope="row">
	<label for="help_email">Help Email</label>
	</th>
	<td>
	<input name="help_email" class="regular-text" type="email" id="help_email" value="' . esc_attr( get_site_option( 'help_email') ) . '" />	<p class="description">Help Email can be added here.</p>
	</td>
	</tr>
	</table>
	';
	/* 
	<tr>
	<th scope="row">Some checkbox</th>
	<td>
	<label>
	<input name="some_checkbox" type="checkbox" value="yes" ' . checked('yes', get_site_option( 'some_checkbox'), false ) . '> Yes, check this checkbox</label></td>
	</tr>
	 */

	echo $mu_setting_fields;  //get form

	submit_button();		
}

add_action( 'network_admin_edit_ms_network_settings', 'ao_multi_save_settings' );

function ao_multi_save_settings(){
 
	check_admin_referer( 'ao-network-validate' ); // Nonce security check

	update_site_option( 'tracking_id', $_POST['tracking_id'] ); // GA code
    update_site_option( 'youtube_url', $_POST['youtube_url'] ); // Youtube url
	update_site_option( 'private_facebook_group', $_POST['private_facebook_group'] ); //facebook group url
	update_site_option( 'rss_feed_url', $_POST['rss_feed_url'] ); //rss feed url
	update_site_option( 'rss_feed_max', $_POST['rss_feed_max'] ); //rss feed MAx
	update_site_option( 'request_consultation_screenShare_meeting', $_POST['request_consultation_screenShare_meeting'] ); //screen share url
	update_site_option( 'site_admin_note', $_POST['site_admin_note'] ); // site admin note
	update_site_option( 'help_email', $_POST['help_email'] ); //help email
	update_site_option( 'google_map_api_key', $_POST['google_map_api_key'] ); // Google Map key
	update_site_option( 'bitmovin_api_key', $_POST['bitmovin_api_key'] ); // Bitmovin API key	 

	wp_redirect( add_query_arg( array(
		'page' => 'ao-settings',
		'updated' => true ), network_admin_url('admin.php')
	)); 
	exit; 
}

add_action( 'network_admin_notices', 'ao_ms_network_notices' );
 
function ao_ms_network_notices(){
 
	if( isset($_GET['page']) && $_GET['page'] == 'ao-settings' && isset( $_GET['updated'] )  ) {
		echo '<div id="message" class="updated notice is-dismissible"><p>Settings updated. Thank You!</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
	}
 
}

/**
 * Display Contact Form 7 responses in a popup.
 */

function ContactForm7_popup() {

	$return = <<<EOT
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
	<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
	<script>	
		jQuery(".wpcf7-form a,.wpcf7-form button").click(function(event) {
			jQuery( document ).one( "ajaxComplete", function(event, xhr, settings) {
				var data = xhr.responseText;
				var jsonResponse = JSON.parse(data);
				 //console.log(jsonResponse);
				
				if(! jsonResponse.hasOwnProperty('into') || jQuery('.wpcf7' + jsonResponse.into).length === 0) return;	
				var response = '<div class="cf7_popup">';
				if(jsonResponse['status']=="mail_sent")
					 response+= '<div class="message"><span style="color:green;font-size:18px;font-weight:500;">' + jsonResponse.message + '</span></div>';
				else
				    response+= '<div class="message"><span style="color:red;font-size:18px;font-weight:500;">' + jsonResponse.message + '</span></div>';
				
					response+='<div>';
				jQuery.fancybox.open(
						response,
						{					
						smallBtn : true,
						toolbar : false
					    }
				);
			});
		});
	</script>
	<style>
		.cf7_popup.fancybox-content{
			background: var(--main-theme-color-contrast);
			
		}
		div.wpcf7-response-output, div.wpcf7-validation-errors { display:none !important; }
		/*span.wpcf7-not-valid-tip { display: block; }*/
		input[aria-invalid="true"], select[aria-invalid="true"] { border-color: #ff2c00; // background-color: rgba(153,0,0,0.3); }
	</style>

EOT;
	echo $return;
}
add_action( 'wp_footer', 'ContactForm7_popup', 20 );
/* 
function pythdiff($R1,$G1,$B1,$R2,$G2,$B2){
    $RD = $R1 - $R2;
    $GD = $G1 - $G2;
    $BD = $B1 - $B2; 
    return  sqrt( $RD * $RD + $GD * $GD + $BD * $BD ) ;
}
//$value = hexdec('ff'); // $value = 255
 */
function hex2rgb($hex) {
	$hex = str_replace("#", "", $hex);
 
	if(strlen($hex) == 3) {
	   $r = hexdec(substr($hex,0,1).substr($hex,0,1));
	   $g = hexdec(substr($hex,1,1).substr($hex,1,1));
	   $b = hexdec(substr($hex,2,1).substr($hex,2,1));
	} else {
	   $r = hexdec(substr($hex,0,2));
	   $g = hexdec(substr($hex,2,2));
	   $b = hexdec(substr($hex,4,2));
	}
	$rgb = array($r, $g, $b);
	//return implode(",", $rgb); // returns the rgb values separated by commas
	return $rgb; // returns an array with the rgb values
 }
 ?>