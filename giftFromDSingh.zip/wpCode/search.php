<?php get_header(); ?>
    <h1>
        <?php if ( have_posts() ) : ?>
        <?php printf( __( 'Search Results for: %s', 'website_name' ), '<span>' . get_search_query() . '</span>' ); ?>
    </h1>
    <ul>
        <li><?php printf( __( '%s', 'telecom' ), '<span>' . get_search_query() . '</span>' ); ?></li>
    </ul>
    <?php else :
        printf( __( '<strong>No results found for: %s</strong>', 'telecom' ), '<span>' . get_search_query() . '</span>' ); ?>
    <?php printf( __( '%s', 'telecom' ), '<span>' . get_search_query() . '</span>' ); ?>
    <?php endif; ?>

    <?php while ( have_posts() ) : the_post(); ?>
    <h4>
        <?php the_title(); ?>
    </h4>
    <span><?= get_the_time('M d,Y'); ?></span>
    <p>
        <?= substr( strip_tags( get_the_excerpt() ),0,180); ?>
    </p>
    <a href="<?= get_the_permalink(); ?>">Read More</a>
    <?php get_template_part( 'content', get_post_format() ); endwhile; ?>
<?php get_footer(); ?>