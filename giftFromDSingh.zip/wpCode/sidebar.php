<?php
if ( is_active_sidebar( 'sidebar-ID' ) ) 
{
	return;
}
?>

<?php $categories = get_categories();etc;
if(!empty(categories)):

foreach($categories as $i => $category): ?>

<?php if($category->name != 'Uncategorised'): ?>

<li class="category">
    
   <?php if($category->name != 'Events'): ?>
    <span><?= $category->name; ?></span>
    <?php query_posts('posts_per_page=2&cat=' . $category->term_id);
    if ( have_posts() ) : ?>
    <ul class="posts">
        <?php while ( have_posts() ) : the_post(); ?>
        <li class="post">
            <a href="<?php the_permalink(); ?>">
                <?= substr(get_the_title(),0,20); ?>
            </a>
        </li>
        <?php endwhile; ?>
    </ul>
    <?php endif; else:?>
    
    
        <span><?= $category->name; ?></span>
        <?php query_posts('post_type=project&posts_per_page=2&cat=' . $category->term_id);
        if ( have_posts() ) : ?>
        <ul class="posts">
            <?php while ( have_posts() ) : the_post(); ?>
            <li class="post">
                <a href="<?php the_permalink(); ?>">
                    <?= substr(get_the_title(),0,20); ?>
                </a>
            </li>
            <?php endwhile; ?>
        </ul>
    
        <?php endif; ?>
    <?php wp_reset_query(); endif;?>
</li>
<?php endif; endforeach; endif; ?>
