<?php get_header(); ?>
<style>
	a[rel="prev"] {
		text-decoration: none;
		display: inline-block;
		padding: 8px 16px;
		background-color: #f1f1f1;
		color: black;
	}

	a[rel="next"] {
		text-decoration: none;
		display: inline-block;
		padding: 8px 16px;
		background-color: #4CAF50;
		color: white;
	}

	a[rel="prev"],
	a[rel="next"]:hover {
		background-color: #ddd;
		color: black;
	}
</style>
<div id="myCarousel" class="carousel banner slide" data-ride="carousel">     
	<div class="carousel-inner">        
		<div class="item active">
			<img src="<?= get_stylesheet_directory_uri(); ?>/images/MaskGroup.png" class="img-responsive" alt="MaskGroup Banner">  
			<div class="text-box post2">            
				<h1><?php the_post(); the_title(); ?></h1>
			</div>                 
		</div>         
	</div>      
</div>
<div class="container">
	<div class="row">
		<div class="col-md-12 col-sm-12 woocommerce">
			<?php the_content(); ?>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-6 col-sm-6">
			<p class="navigation previous">
				<?php previous_post_link(); ?>
			</p>
		</div>
		<div class="col-md-6 col-sm-6 text-right">
			<p class="navigation next">
				<?php next_post_link(); ?>
			</p>
		</div>
	</div>
		<div class="row text-center">
		<?php
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;
		?>
	</div>
</div>
<?php get_footer(); ?>