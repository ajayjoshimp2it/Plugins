<?php get_header(); ?>

<?php if ( have_posts() ) : ?>

<?php printf( __( 'Tag Archives: %s', 'theme Name' ), '<span>' . single_tag_title( '', true ) . '</span>' ); ?>

<?php if ( tag_description() ) : ?>

<?php echo tag_description(); ?>

<?php endif; ?>

			<?php while ( have_posts() ) : the_post(); ?>

		<?php else : ?>

			Sorry! No Posts match:-

<?php endif; ?>

<?php get_footer(); ?>