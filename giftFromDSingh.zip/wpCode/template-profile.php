<?php /* Template Name: Profile */ 



/* Inner Page Header */
if(!is_user_logged_in()){
	wp_redirect(home_url('login'));
}

get_header();

locate_template('default-template/inner-page-header.php',true,true);
global $current_user;
if(isset($_POST['submit_profile']) && (!empty($_POST['submit_profile']))){

	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$my_bio = $_POST['my_bio'];
	$current_password = $_POST['current_password'];
	$new_password = $_POST['new_password'];
	$confirm_password = $_POST['confirm_password'];

	
	if(!empty($first_name )){
		update_user_meta( $current_user->ID, 'first_name', esc_attr( $first_name) );
		$error_msg = 'yes';
	}

	if(!empty($last_name )){
		update_user_meta($current_user->ID, 'last_name', esc_attr( $last_name ) );
		$error_msg = 'yes';
	}

	if(!empty($my_bio)){
		 update_user_meta( $current_user->ID, 'description', esc_attr( $my_bio ) );
		 $error_msg = 'yes';
	}

	if(!empty($current_password)){
		if(wp_check_password($current_password, $current_user->data->user_pass, $current_user->ID )){

			if((!empty($new_password)) && (!empty($confirm_password))) {
				if($new_password == $confirm_password){
					wp_update_user( array( 'ID' => $current_user->ID, 'user_pass' => esc_attr( $new_password ) ) );
					$error_msg = 'yes';
				} else{
					$error_msg = "The passwords you entered do not match.  Your password was not updated.";
				}
			}
		} else {
			$error_msg = "Current password is wrong";
		}
		
	}
	global $wpdb;
	$user_id = get_current_user_id();
	if((isset($_FILES['profile_img_avat'])) && (!empty($_FILES['profile_img_avat']['tmp_name']))){
		require_once(ABSPATH . "wp-admin" . '/includes/image.php');
		require_once(ABSPATH . "wp-admin" . '/includes/file.php');
		require_once(ABSPATH . "wp-admin" . '/includes/media.php');
		
		$attachment_id = media_handle_upload('profile_img_avat', $user_id);

		if (!is_wp_error($attachment_id)) {
			update_user_meta( $user_id, "wp_user_avatar", $attachment_id);
			$image_upd = "Profile Image Updated Successfully.";

			$action ="Profile Image Updated";
			
		}else {
			$image_upd = "Profile Image Not Updated";
		}
	}

}


$login_deutype = get_user_meta($current_user->ID,'deutype',true);
$social_check = 'no';
if($login_deutype == 'twitter'){
	$social_check = 'yes';
} else if($login_deutype == 'google'){
	$social_check = 'yes';

}else if($login_deutype == 'facebook'){
	$social_check = 'yes';
}
?>

<div class="my_account_container section-what-you-get">
	<div class="my_account_div container p-4">
		<div class="row">
            <div class="col-sm-12 col-heading d-flex flex-column align-items-center">
                <h2 class="text-uppercase text-center font-heading font-weight-bold">Baine Realty</h2>
                <a class="heading-after-img-wrapper d-flex align-items-center">
                    <img class="heading-after-img" src="<?= get_template_directory_uri(); ?>/images/Log_small.png" alt="IDX Image">
                </a>
            </div>
        </div>

		<div class="my-4">
			<?php if($error_msg == 'yes'){
				echo '<p class="succe_msg">Profile edit successfully</p>';
			} else if(!empty($error_msg)){
				echo '<p class="error_msg">'.$error_msg.'</p>';
			} ?>
			<form action="#" method="post" enctype="multipart/form-data" class="my_account_form">
				<div class="row mx-0">
					<!-- <div class="col-md-12">
						<h4 class="user_name"><?php //the_author_meta( 'first_name', $current_user->ID ); ?> <?php //the_author_meta( 'last_name', $current_user->ID ); ?></h4>
					</div> -->
					<div class="clerfix"></div>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-user"></i>
							<input class="form-control box" type="text" name="first_name" placeholder="First Name" value="<?php the_author_meta( 'first_name', $current_user->ID ); ?>" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-user"></i>
							<input class="form-control box" type="text" name="last_name" placeholder="Last Name" value="<?php the_author_meta( 'last_name', $current_user->ID ); ?>" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-envelope"></i>
							<input class="form-control box" type="text" name="email" placeholder="E-mail" value="<?php the_author_meta( 'email', $current_user->ID ); ?>" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
						</div>
					</div>
					<div class="clerfix"></div>
					<?php if($social_check != 'yes') { ?>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-lock"></i>
							<input class="form-control box" type="password" name="current_password" placeholder="Current Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false">
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-lock"></i>
							<input class="form-control box" type="password" name="new_password" placeholder="New Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-12 px-1">
						<div>
						    <i class="fa fa-lock"></i>
							<input class="form-control box" type="password" name="confirm_password" placeholder="Confirm Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
						</div>
					</div>
					<div class="col-md-12 text-center mt-2">
						<button class="color_theme btn my_account_btn btn-green" type="submit" name="submit_profile" value="save">Save Changes</button>
					</div>
					<?php } ?>
				</div>
			</form>
		</div>
	</div>
</div>

<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

<?php get_footer(); ?>