<?php get_header();?>

<div class="banner"></div>
<div class="products_cart">
    <div class="container">
        <div class="row">
            <?php
		    woocommerce_content();
		?>
        </div>
    </div>
</div>
<div id="footer-text" style="background-color:white">
    <h3>Do you want bigger breasts?</h3>
    <p class="text-center">Hi, I'm Jules a breast enlargement adviser at Avalon Essentials. I'm determined to help you grow larger breasts naturally! Are you ready for your breasts to be larger and firmer?</p>

    <h3>Yes, get me started!</h3>
    <p class="text-center">I'm ready to use the #1 breast enlargement system.</p>
    <div class="btn_cen">
				<!--<img src="https://www.bountifulbreast.com/wp-content/themes/bountifulbreast/images/redo-arrow.png" class="img-responsive" alt="Arrow">--><a href="https://www.bountifulbreast.com/order-now/">Breast Enlargement Packages and discounts here!</a>
				</div>
    

</div>

<?php get_footer();?>