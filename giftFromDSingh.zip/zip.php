<?php
function create_zip($files = array(),$destination = '',$overwrite = false) 
{
	if(file_exists($destination) && !$overwrite) { return false; break; }
	$valid_files = array();
    $invalid_files = array();
	if(is_array($files)) 
    {
		foreach($files as $file) 
        {
			if(file_exists($file)) 
            {
				$valid_files[] = $file;
			}else{
                $invalid_files[] = $file;
            }
		}
	}
	if(count($valid_files)) 
    {
		$zip = new ZipArchive();
		if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) 
        {
			return false; break;
		}
		foreach($valid_files as $file) 
        {
			$zip->addFile($file,$file);
		}
		echo 'The zip archive contains ',$zip->numFiles,' files with a status of ',$zip->status;
        echo "<br>Not found File";
		foreach($invalid_files as $invalid_file) 
        {
			echo $invalid_file."<br>";
		}
		$zip->close();
		return file_exists($destination);
	}
	else
	{
		return false;
	}
}

$files_to_zip = array('');
$result = create_zip($files_to_zip,'my-archive.zip');
if($result){
    echo "Ho Gayi";
}else{
    echo "Sorry!";
}
?>