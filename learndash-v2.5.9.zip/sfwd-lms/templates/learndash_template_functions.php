<?php
/**
 * Template helper functions.
 * 
 * @since 2.1.0
 * 
 * @package LearnDash\Template
 */
?>