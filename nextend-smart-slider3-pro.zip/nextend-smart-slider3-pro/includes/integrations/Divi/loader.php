<?php

if (!class_exists('ET_Builder_Element')) {
    return;
}

require_once dirname(__FILE__) . '/includes/modules/SmartSlider3/SmartSlider3.php';
require_once dirname(__FILE__) . '/includes/modules/SmartSlider3FullWidth/SmartSlider3FullWidth.php';