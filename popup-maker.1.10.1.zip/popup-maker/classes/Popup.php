<?php

// Empty class extender here for backward compatibility.
class PUM_Popup extends PUM_Model_Popup {}