<div class="hover-section-content-wrapper" data-image="<?php echo $featured_image; ?>">
	<?php echo $list_img.$list_title;
	echo '<div class="hover-content-inner-hover">'.$list_sub_title.$description.$loop_button.'</div>'; ?>
</div>
