<?php echo $list_title; ?>

