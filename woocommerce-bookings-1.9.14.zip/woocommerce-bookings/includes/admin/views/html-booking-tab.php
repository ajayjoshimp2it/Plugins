<li class="bookings_tab bookings_resources_tab advanced_options show_if_booking"><a href="#bookings_resources"><?php _e( 'Resources', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_availability_tab advanced_options show_if_booking"><a href="#bookings_availability"><?php _e( 'Availability', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_pricing_tab advanced_options show_if_booking"><a href="#bookings_pricing"><?php _e( 'Costs', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_persons_tab advanced_options show_if_booking"><a href="#bookings_persons"><?php _e( 'Persons', 'woocommerce-bookings' ); ?></a></li>
