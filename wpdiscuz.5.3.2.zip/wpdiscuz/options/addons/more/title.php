<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<li><?php _e('More Addons...', 'wpdiscuz'); ?></li>