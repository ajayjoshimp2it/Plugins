<?php
if (!defined('ABSPATH')) {
    exit();
}
?>
<li class='wpd-list-item'>
    <i class='fas fa-bell'></i>
    <span><?php  echo $this->optionsSerialized->phrases['wc_user_settings_subscriptions']; ?></span>
    <input class='wpd-rel' type='hidden' value='wpd-content-item-2'/>
</li>